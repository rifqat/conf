from django.contrib import admin
from .models import Status, Jadval
# Register your models here.
admin.site.register(Status)
admin.site.register(Jadval)