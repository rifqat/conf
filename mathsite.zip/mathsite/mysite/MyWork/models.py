from django.db import models

# Create your models here.
class Status(models.Model):
    Nomi   = models.CharField(max_length=30)

    def __str__(self):
        return  self.Nomi


class Jadval(models.Model):
    #nominator information
    FISH = models.CharField(max_length=300)
    Tel = models.CharField(max_length=300)
    Email = models.EmailField(max_length=254)
    StatusId = models.ForeignKey(Status,on_delete=models.CASCADE)
    Vaqti = models.DateTimeField(auto_now_add=True)
    Mword= models.FileField()
    Mtex= models.FileField()


    def __str__(self):
        return self.FISH

