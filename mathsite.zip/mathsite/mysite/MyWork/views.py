from django.shortcuts import redirect
from django.contrib.auth.models import User
from django.contrib import auth
from django.shortcuts import render, get_object_or_404
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from .models import Status,Jadval
from zipfile import ZipFile
from django.contrib.admin.views.decorators import staff_member_required
import os
from django.conf import settings
from django.http import HttpResponse, Http404


# Create your views here.
def home(request):
    bir = "bir"
    ikki = "ikki"
    return render(request, 'MyWork/home.html',{"bir":bir,"ikki":ikki})

def domlahaqida(request):
    return render(request, 'MyWork/domlahaqida.html')

def dastur(request):
    return render(request, 'MyWork/dastur.html')

def toplam(request):
    return render(request, 'MyWork/toplam.html')

def tashqomita(request):
    return render(request, 'MyWork/tashqomita.html')

def axati(request):
    return render(request, 'MyWork/axati.html')

def shoba(request):
    return render(request, 'MyWork/shoba.html')

def texnamuna(request):
    return render(request, 'MyWork/texnamuna.html')

def sanalar(request):
    return render(request, 'MyWork/sanalar.html')

def certif(request):
    return render(request, 'MyWork/certif.html')

def allmedia(request):
    return render(request, 'MyWork/allmedia.html')

def succes(request):
    return render(request, 'MyWork/succes.html')


def getmaqola(request):
    if request.method == 'POST':
        fish = request.POST['fish']
        tel = request.POST['tel']
        email = request.POST['email']
        status = get_object_or_404(Status, pk=1)
        print("text ", status)

        # upload file

        mword = None
        if (request.FILES.get('mword', None) and request.method == 'POST'):
            mword = request.FILES.get('mword', None)
            fs = FileSystemStorage()
            filename = fs.save(str(fish.replace(" ","")) + 'Word.' + str(mword).split('.')[-1], mword)
            uploaded_file_url = fs.url(filename)
            print("faylkini", mword, filename)
            # os.remove('/media/'+mword)
            mword = filename


        mtex = None
        if (request.FILES.get('mtex', None) and request.method == 'POST'):
            mtex = request.FILES.get('mtex', None)
            fs = FileSystemStorage()
            filename = fs.save(str(fish.replace(" ","")) + 'Tex.' + str(mword).split('.')[-1], mtex)
            uploaded_file_url = fs.url(filename)
            print(mtex,filename,uploaded_file_url)
            mtex = filename

        n = Jadval(FISH=fish, Tel=tel, Email=email, StatusId=status, Mword=mword, Mtex=mtex)
        n.save()
        return redirect('succes')
    else:
        return render(request, 'MyWork/getmaqola.html')


def login(request):
    if request.method == 'POST':
        user = auth.authenticate(username=request.POST['login'],password=request.POST['parol'])
        if user is not None:
            auth.login(request, user)
            return redirect('home')
        else:
            return render(request, 'MyWork/login.html',{'error':'Login yoki Parol xato.'})
    else:
        return render(request, 'MyWork/login.html')


def logout(request):
    if request.method == 'POST':
        auth.logout(request)
        return redirect('home')

@staff_member_required
def maqola(request):
    jadval =Jadval.objects.all().order_by('-id')
    statuslar = Status.objects.all()
    print(statuslar)
    return render(request, 'MyWork/maqola.html',{'jadval':jadval})

@staff_member_required
def tastiq(request,myId):
    print("keldi", myId)
    maqola = get_object_or_404(Jadval,pk=myId)
    maqola.StatusId=get_object_or_404(Status, pk=2)
    maqola.save()

    return redirect('maqola')

@staff_member_required
def minus(request):
    print("keldi")
    jadval = Jadval.objects.filter(StatusId=1).order_by('-id')
    return render(request, 'MyWork/maqola.html', {'jadval': jadval})

@staff_member_required
def plus(request):
    print("keldi")
    jadval = Jadval.objects.filter(StatusId=2).order_by('-id')
    return render(request, 'MyWork/maqola.html', {'jadval': jadval})

from django.conf import settings
from django.conf.urls.static import static




def saqlash(request):
    print(static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT),"link")
    zipObj = ZipFile('maqolalar.zip', 'w')
    jadval = Jadval.objects.filter(StatusId=2).order_by('-id')
    # print(settings.MEDIA_ROOT)
    for i in  jadval:
        print(i.Mword.name)
        print(i.Mword.url)
        print(i.Mword.path)
        zipObj.write(i.Mword.path)
        zipObj.write(i.Mtex.path)

        # # close the Zip File
    zipObj.close()

    file_path = os.path.join('maqolalar.zip')
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/zip")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404


    # return render(request, 'MyWork/saqlash.html', {'jadval': jadval})


# def jismoniy(request):
#     if request.method == 'POST':
#         fish = request.POST['fish']
#         hudut = request.POST['hudut_name']
#         muassasa = request.POST['talim_muassasasi']
#         telefon = request.POST['telefon']
#         sport_turi = request.POST['sport_turi']
#         turi = request.POST['turi']
#         tolov = request.POST['tolov']
#         summa = 11000
#         Vaqti = datetime.today().strftime('%Y-%m-%d')
#         if tolov == "payme":
#             if fish != "" and hudut != "" and muassasa != "" and telefon != "" and sport_turi != "" and turi != "" and request.FILES.get(
#                     'pasport_nusxalari', None) and request.FILES.get('rasmlar', None) and request.FILES.get(
#                     'malumotnomalar', None):
#
#                 pasport_nusxalari = (request.FILES.get('pasport_nusxalari', None))
#                 rasmlar = request.FILES.get('rasmlar', None)
#                 malumotnomalar = request.FILES.get('malumotnomalar', None)
#                 sport_id = Sport_razriyad_jismoniy.objects.all().order_by('-id')[:1]
#                 for i in sport_id:
#                     spor_id = int(i.id) + 1
#                 fss = FileSystemStorage()
#                 file = fss.save('razriyad/jismoniy/' + str(spor_id) + '1.' + str(pasport_nusxalari).split('.')[-1],
#                                 malumotnomalar)
#                 file_url = fss.url(file)
#                 file1 = fss.save('razriyad/jismoniy/' + str(spor_id) + '2.' + str(rasmlar).split('.')[-1],
#                                  malumotnomalar)
#                 file_url1 = fss.url(file)
#                 file2 = fss.save('razriyad/jismoniy/' + str(spor_id) + '3.' + str(malumotnomalar).split('.')[-1],
#                                  malumotnomalar)
#                 file_url2 = fss.url(file)
#
#                 sport_j = Sport_razriyad_jismoniy()
#                 sport_j.Razriyad_turi = turi
#                 sport_j.FISH = fish
#                 sport_j.Hudud_nomi = hudut
#                 sport_j.Tahsil_olayotgan_talim_muassasasi = muassasa
#                 sport_j.Telefon = telefon
#                 sport_j.Tanlangan_sport_turi = sport_turi
#                 sport_j.Passportlar = file
#                 sport_j.rasmlar_3_4 = file1
#                 sport_j.malumotnomalar = file2
#                 sport_j.sanasi = Vaqti
#                 sport_j.tasdiq = 0
#                 sport_j.save()
#                 order_id = sport_j.id
#                 form = PaymeCardForm()
#                 context = {'form': form, 'order_id': 1, 'Vaqti': Vaqti, 'summa': summa}
#                 return render(request, 'tolov_c1.html', context)
#             else:
#                 return render(request, 'azolik.html', {'xato': "* белгиси қўйилган маълумотларни киритилиши шарт!!!"})
#         else:
#             return render(request, 'sport_razriyadlari.html',
#                           {'xato': "* белгиси қўйилган маълумотларни киритилиши шарт!!!"})
#     return render(request, 'sport_razriyadlari.html', {'xato': "* белгиси қўйилган маълумотларни киритилиши шарт!!!"})