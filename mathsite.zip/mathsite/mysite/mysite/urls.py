"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
import MyWork.views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',MyWork.views.home, name='home'),
    path('domlahaqida/',MyWork.views.domlahaqida, name='domlahaqida'),
    path('dastur/', MyWork.views.dastur, name='dastur'),
    path('toplam/', MyWork.views.toplam, name='toplam'),
    path('tashqomita/', MyWork.views.tashqomita, name='tashqomita'),
    path('axati/', MyWork.views.axati, name='axati'),
    path('shoba/', MyWork.views.shoba, name='shoba'),
    path('texnamuna/', MyWork.views.texnamuna, name='texnamuna'),
    path('sanalar/', MyWork.views.sanalar, name='sanalar'),
    path('certif/', MyWork.views.certif, name='certif'),
    path('allmedia/', MyWork.views.allmedia, name='allmedia'),
    path('getmaqola/', MyWork.views.getmaqola, name='getmaqola'),
    path('succes/', MyWork.views.succes, name='succes'),
    path('login/', MyWork.views.login, name='login'),
    path('logout/', MyWork.views.logout, name='logout'),

    path('maqola/', MyWork.views.maqola, name='maqola'),
    path('tastiq/<int:myId>/', MyWork.views.tastiq, name='tastiq'),
    path('minus/', MyWork.views.minus, name='minus'),
    path('plus/', MyWork.views.plus, name='plus'),
    path('saqlash/', MyWork.views.saqlash, name='saqlash'),

              ]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
