<?php
session_start();
require_once("connect.php");
check_user($conn);
$error="";
if (isset($_POST['submit'])) {
    if (isset($_POST['fam']) && strlen($_POST['fam']) > 3) {
        if (isset($_POST['ism']) && strlen($_POST['ism']) > 3) {
            if (isset($_POST['otasi']) && strlen($_POST['otasi']) > 3) {
                if (isset($_POST['tel']) && strlen($_POST['tel']) > 3) {
                    if (isset($_POST['email']) && strlen($_POST['email']) > 3) {
                        $sql="UPDATE users SET fam='".str_replace("'", "/g", $_POST['fam'])."', ism='".str_replace("'", "/g", $_POST['ism'])."', otasi='".str_replace("'", "/g", $_POST['otasi'])."', tel='".str_replace("'", "/g", $_POST['tel'])."', email='".str_replace("'", "/g", $_POST['email'])."' WHERE id=".$_SESSION['id']." LIMIT 1;";
                        if ($resp=mysqli_query($conn, $sql)){

                        }
                        else die(mysqli_error($conn));
                    }
                    else $error="An email error has been entered!";
                }
                else $error="The phone has entered an error!";
            }
            else $error="Your middle name is entered incorrectly!";
        }
        else $error="Your name is entered incorrectly!";
    }
    else $error="Your last name is entered incorrectly!";
}
$sql = "SELECT fam,ism, otasi, tel, email, login FROM users WHERE id=" . $_SESSION['id'] . " LIMIT 1;";
if (!$resp = mysqli_query($conn, $sql)) {
    die(mysqli_error($conn));
}
$row = mysqli_fetch_array($resp);
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About me</title>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png" />
    <link href="css/style.min.css" rel="stylesheet">
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php include("head1.php"); ?>
        <?php include("menu.php"); ?>
        <div class="page-wrapper" style="min-height: 250px;">
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">About me</h4>
                    </div>

                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                <form class="form-horizontal form-material" method="POST" action="">
                    <div class="col-lg-12 col-xlg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="col-lg-12 col-xlg-12 col-md-12 col-sm-12">
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Your last name</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input name="fam" value="<?= str_replace("/g", "'", $row['fam']) ?>" type="text" class="form-control p-0 border-0">
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label for="example-email" class="col-md-12 p-0">Your name</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input name="ism" value="<?= str_replace("/g", "'", $row['ism']) ?>" type="text" class="form-control p-0 border-0" name="example-email" id="example-email">
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Your middle name</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input name="otasi" value="<?= str_replace("/g", "'", $row['otasi']) ?>" type="text" class="form-control p-0 border-0">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-xlg-6 col-md-6 col-sm-12">
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Your phone</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input name="tel" value="<?= str_replace("/g", "'", $row['tel']) ?>" type="text" class="form-control p-0 border-0">
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Your e-mail</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input name="email" value="<?= str_replace("/g", "'", $row['email']) ?>" type="text" class="form-control p-0 border-0">
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Your login</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input disabled name="email" value="<?= str_replace("/g", "'", $row['login']) ?>" type="text" class="form-control p-0 border-0">
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <div class="col-sm-12">
                                            <input type="submit" name="submit" class="btn btn-success" value="Save">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
            <footer class="footer text-center"> 2022 © Bukhara State University <a href="https://buxdu.uz/">Buxdu.uz</a>
            </footer>
        </div>
    </div>
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>