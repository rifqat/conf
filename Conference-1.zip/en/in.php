<?php
session_start();
$error = "";
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 1) {
        $_SESSION['msg'] = "You have successfully registered. Please log in!";
    }
    header("location: ./in.php");
}
if (isset($_SESSION['msg']) && $_SESSION['msg'] != "") {
    $error = $_SESSION['msg'];
    $_SESSION['msg'] = "";
}
if (isset($_POST['submit'])) {
    require_once("connect.php");
    $sql = "SELECT id, parol,active FROM users where login='" . str_replace("'", "/g", $_POST['login']) . "' AND active>=1";
    if ($resp = mysqli_query($conn, $sql)) {
        $i=0;
        while ($row = mysqli_fetch_array($resp)) {
            $i++;
            if ($row['parol'] == md5(str_replace("'", "/g", $_POST['parol']))) {
                $_SESSION['id'] = $row['id'];
                $_SESSION['parol'] = $row['parol'];
                $_SESSION['active'] = $row['active'];
                header("location: ./maqolalar.php");
            } else {
                $error = "Login or password error!";
            }
        }
        if ($i==0){
            $error="Login or password error!";
        }
    } else {
        $error = "Login or password error!";
    }
}
?>

<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Log in</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/icon/favicon.png" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
</head>

<body>
    <main class="login-bg">
        <div class="login-form-area">
            <div class="login-form">
                <form action="" method="post">
                    <div class="login-heading">
                        <span>Log in  </span>
                        <p>
                            Don't have an account?
                            <a class="text-danger" href="up.php">Sign up for it</a>
                        </p>
                    </div>
                    <div class="w-100 bg-danger text-white text-center"><?= $error ?></div>
                    <div class="input-box">
                        <div class="single-input-fields">
                            <label>Your login</label>
                            <input name="login" type="text" placeholder="Login..." />
                        </div>
                        <div class="single-input-fields">
                            <label>Your password</label>
                            <input name="parol" type="password" placeholder="Password..." />
                        </div>
                    </div>

                    <div class="login-footer d-flex justify-content-end">

                        <input type="submit" name="submit" value="Log in" class="submit-btn3">
                    </div>
                </form>
            </div>
        </div>
    </main>
</body>

</html>