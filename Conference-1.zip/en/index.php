﻿<?php
session_start();
if (isset($_SESSION['lang']) && ($_SESSION['lang']!='en')){
  if ($_SESSION['lang']=='ru' || $_SESSION['lang']=='uz'){
    header("location: ../".$_SESSION['lang']."/");
  }
} else {
  $_SESSION['lang']='en';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <meta name="author" content="Surjith S M">

  <!-- <script src="../../cdn-cgi/apps/head/OkbNSnEV_PNHTKP2_EYPrFNyZ8Q.js"></script> -->
  <link rel="shortcut icon" href="../uz/images/favicon.png">

  <title>Conferences - Bukhara  State University</title>

  <link href="../uz/css/bootstrap.min.css" rel="stylesheet">

  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,600' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

  <link href="../uz/css/plugins/animate.css" rel="stylesheet">
  <link href="../uz/css/plugins/slick.css" rel="stylesheet">
  <link href="../uz/css/plugins/magnific-popup.css" rel="stylesheet">
  <link href="../uz/css/plugins/font-awesome.css" rel="stylesheet">
  <link href="../uz/css/plugins/streamline-icons.css" rel="stylesheet">

  <link href="../uz/css/event.css" rel="stylesheet">


  <link href="../uz/css/themes/green.css" rel="stylesheet">


  <link rel="stylesheet" title="green" media="screen" href="../uz/css/themes/green.css">
  <link rel="alternate stylesheet" title="purple" media="screen" href="../uz/css/themes/purple.css">
  <link rel="alternate stylesheet" title="red" media="screen" href="../uz/css/themes/red.css">
  <link rel="alternate stylesheet" title="mint" media="screen" href="../uz/css/themes/mint.css">
  <link rel="alternate stylesheet" title="blue" media="screen" href="../uz/css/themes/blue.css">
  <link rel="alternate stylesheet" title="yellow" media="screen" href="../uz/css/themes/yellow.css">
  <link rel="alternate stylesheet" title="black" media="screen" href="../uz/css/themes/black.css">

  <link href="../uz/css/demo.css" rel="stylesheet">


  <!--[if lt IE 9]>
  <script src="../uz/js/ie/respond.min.js"></script>
  <![endif]-->

  <script src="../uz/js/modernizr.min.js"></script>

  <script>
    console.log(`<?=$_SERVER['PHP_SELF']?>`)
  </script>
  <script src="../uz/js/plugins/pace.js"></script>
<style>
.header_top-bg .btn-success:hover{
	background-color: white;
	color: #4eae49;
}

.header_top-bg .btn-success{
	background-color: transparent;
	color: white;
}

.footer_bottom-bg .btn-outline:hover{
	background-color: #4eae49;
	color: white;
}

.footer_bottom-bg .btn-outline{
	background-color:transparent;
	color: #4eae49;
}

.footer_bottom-bg .btn-success:hover{
	background-color:transparent;
	color: #4eae49;
}
.select_lang{
  padding: 0;
  margin: 0;
  position: fixed;
  right: 12px;
  top: 12px;
  color: #fff;
  z-index: 1050;
  font-weight: bold;
}

.select_lang li.active a{
  color: #fff;
  font-weight: 900;
}

.select_lang li{
  list-style-type: none;
}

.select_lang li{
  transition: all 0.4s ease;
  position: absolute;
  display: none;
  top: 0;
  right: 0;
  padding: 8px;
  z-index: -4;
  font-weight: bold;
}

.select_lang.show li{
  z-index: 1050;
  position: unset;
}

.select_lang li.active{
  display: block;
  z-index: 9;
  border-radius: 8px;
  background-color: #ccc;
}

.select_lang.show li{
  display: block;
}

.select_lang.show li a{
  background-color: #ccc;
  color: #fff;
 
}

ul.select_lang.show {
  transition: all 0.4s ease;
  background-color: #ccc;
  border-radius: 8px;
}

*{
  margin: 0;
}
</style>
</head>

<body class="animate-page" data-spy="scroll" data-target="#navbar" data-offset="100">

  <div class="preloader"></div>

  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
          aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#"><img style="width: 100px;" src="../uz/images/logo.png" alt="logo"> </a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="index.php#bosh">Home page</a></li>
          <li><a href="#talab">Requirements</a></li>
          <li><a href="../uploads/2022/Dastur_(Xalqaro konferensiya -2022 - BuxDU).pdf">Program</a></li>
          <li><a href="../uploads/2022/TUPLAM_(Xalqaro konferensiya-2022-BuxDU).pdf">Collection</a></li>
          <li class="dropdown">
                    <a href="#files" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Files<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="../files/cert/index.php">Certificates</a></li>
                        <li><a href=".#">Media</a></li>               
                    </ul>
            </li>
          <li class="dropdown">
                    <a href="#flyer" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Flyer<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="../uploads/flyer/Xalqaro konferensiya-2022-3_en.pdf">Flyer(EN)</a></li>
                        <li><a href="../uploads/flyer/Xalqaro konferensiya-2022-1_uz.pdf">Flyer(UZ)</a></li>
                        <li><a href="../uploads/flyer/Xalqaro konferensiya-2022-2_ru.pdf">Flyer(RU)</a></li>                        
                    </ul>
                </li>
          <li><a href="#contact">Contact</a></li>
          <li><a href="in.php">Log in</a></li>
          <li><a href="up.php" class="btn btn-outline">Register</a></li>
          </li>
        </ul>
      </div>

    </div>
  </nav>

  <header id="top" class="header">
    <ul class="select_lang">
      <li class=""> <a href="../?lang=uz">UZ</a> </li>
      <li class="active"><a href="#">EN</a></li>
    </ul>
    <div class="container">
      <div class="header_top-bg">
        <div class="logo">
         
         
          <img style="width: 150px;" src="../uz/images/sponsor_1.png" data-toggle="tooltip" title="National University of Uzbekistan">
       
          <img style="width: 150px;" src="../uz/images/sponsor_2.png" data-toggle="tooltip" title="Institute of mathematics named after V.I.Romanovsky AS RUz">

          <img style="width: 150px;" src="../uz/images/sponsor_3.png" data-toggle="tooltip" title="Tashkent State Transport University ">
          <img style="width: 250px;" src="../uz/images/buxdu.png" data-toggle="tooltip" title="Bukhara State University" >

        </div>
        <b>National University of Uzbekistan, Institute of mathematics named after V.I.Romanovsky AS RUz, Tashkent State Transport University and Bukhara State University</b>
      </div>
       <h1 class="headline wow fadeInDown" data-wow-delay="0.1s">“International scientific and practical conference on "Modern problems of applied mathematics and information technology."</h1> 
       <h3><small>(May 11-12,2022)<small></h3>
       <h4 class="headline wow fadeInDown" data-wow-delay="0.1s">Articles are accepted until April 30, 2022</h4>
      <div class="header_top-bg">
  <a class="btn btn-outline btn-success btn-xl wow zoomIn" href="in.php">Log in</a>
        <a class="btn btn-default btn-xl wow zoomIn" href="up.php">Register</a>
        </p>
      </div>
    </div>

  </header>


<div class="highlight">
    <div class="container">
      <div class="row">
          
          <div class="well well-lg text-danger"><h3>The deadline for submission of articles to the conference has expired</h3>
          </div>
      
      </div>
    </div>
  </div>


<section id="nearby" class="highlight accommodation">
    <div class="container">
      <div class="section-title wow fadeInUp">
        <h4>SESSIONS</h4>       
      </div>
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 1. Mathematical analysis.</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 2. Algebra and geometry</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 3. Differential equations and mathematical physics</h6>             
            </div>
          </div>
        </div>
        
         <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 4. Computational mathematics and mathematical modeling</h6>             
            </div>
          </div>
        </div>


      </div>

      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 5. Algorithm theory and programming technologies</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 6. Artificial intelligence</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 7. Information security</h6>             
            </div>
          </div>
        </div>
        
         <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>Session 8. Digital technologies in education</h6>             
            </div>
          </div>
        </div>


      </div>
    </div>

  </section>

 



  <section id="talab" class="benefits">
    <div class="container">
      <div class="section-title wow fadeInUp">
        <h4>What to consider?</h4>
      </div>
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <div class="row">
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInLeft">
                <div class="benefit-icon"><i class="icon icon-settings-streamline"> </i></div>
                <h6 class="benefit-title">Requirements for materials</h6>
                <p>Conference materials in electronic file. File name of an article(Full name of an Author_name of the article) in Microsoft Word Times New Roman format, size 14 line spacing 1.5, pages left and top marginsn 2.5 cm, bottom and right morgins 2cm, line start- 1cm</p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInRight">
                <div class="benefit-icon"><i class="icon icon-settings-streamline-2"> </i></div>
                <h6 class="benefit-title">For information</h6>
                <p>Organization costs for the conference and the cost of publishing a collection of materials are set 100,000 soums for each article (organization fees are not charged from foreign authors ). The size of the submitted article should not exceed 2 pages. Conference materials are available in Uzbek, Russian and English. One participant can submit a maximum of 2 articles.
                </p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInLeft">
                <div class="benefit-icon"><i class="icon icon-link-streamline"> </i></div>
                <h6 class="benefit-title">Sources</h6>
                <p>Sources and references should be in the main text..</p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInRight">
                <div class="benefit-icon"> <i class="icon icon-speech-streamline-talk-user"> </i></div>
                <h6 class="benefit-title">Important</h6>
               <p>Papers for participation in the international conference will be accepted until April 30, 2022. Selected articles will be published in the scientific journals SCOPUS, Web of Science after the conference. You can send your questions, complaints and suggestions on the use of the platform, account replenishment to the system administrator Hazratov Fazliddin</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>


  


  <div class="highlight">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <div class="contact-box">
            <img src="../uz/images/location-icon.png" alt="location icon" class="wow zoomIn">
            <h5>Address</h5>
            <p>Buxoro State University,  
              <br>11,M.Iqbol street, Bukhara, Uzbekistan
              <br>
              <br>
              <br>
            </p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="contact-box">
            <img src="../uz/images/email-icon.png" alt="email icon" class="wow zoomIn" data-wow-delay="0.3s">
              <h5>Contacts</h5>
              <p>
              <br> <a
                href="https://t.me/confbuxduuz"><span
                  class="__cf_telegramm__"
                  >https://t.me/confbuxduuz</span></a>
              <br>
              <br> +998 (33) 407 8797 - Fazliddin Hazratov              
              <br> +998 (91) 648 3529 - Ozod Jalolov
              <br> Е-mail: hazratovf@gmail.com 
              <br> Card : 8600-1309-3005-9714 (Fazliddin Hazratov)
            </p>
          </div>
        </div>
      </div>

    </div>
  </div>

  
  
  <footer>  
    <p> <small class="text-muted">Buxdu.uz 2022 &copy; All rights reserved</small></p>
  </footer>
  <a href="#top" class="back_to_top"><img src="../uz/images/back_to_top.png" alt="back to top"></a>
  <!-- <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
  <script src="../uz/js/jquery.min.js"></script>

  <script src="../uz/js/bootstrap.min.js"></script>

  <!-- <script src="../uz/js/plugins/countdown.js"></script> -->
  <script src="../uz/js/plugins/wow.js"></script>
  <script src="../uz/js/plugins/slick.js"></script>
  <script src="../uz/js/plugins/magnific-popup.js"></script>
  <!-- <script src="../uz/js/plugins/validate.js"></script> -->
  <script src="../uz/js/plugins/appear.js"></script>
  <!-- <script src="../uz/js/plugins/count-to.js"></script> -->
  <script src="../uz/js/plugins/nicescroll.js"></script>

  <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDMTUkJAmi1ahsx9uCGSgmcSmqDTBF9ygg"></script> -->
  <!-- <script src="../uz/js/plugins/infobox.js"></script> -->
  <!-- <script src="../uz/js/plugins/google-map.js"></script> -->
  <!-- <script src="../uz/js/plugins/directions.js"></script> -->

  <!-- <script src="../uz/js/plugins/style-switcher.js"></script> -->

  <!-- <script src="../uz/js/includes/subscribe.js"></script> -->
  <!-- <script src="../uz/js/includes/contact_form.js"></script> -->

  <script src="../uz/js/main.js"></script>
  <script>
    document.querySelector(".select_lang .active").addEventListener("click", function(){
      document.querySelector(".select_lang").classList.toggle("show");
    })
  </script>
</body>
</html>