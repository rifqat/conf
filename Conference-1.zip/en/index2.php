<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Konferensiyalar</title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png" />

  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
  <link rel="stylesheet" href="assets/css/slicknav.css">
  <link rel="stylesheet" href="assets/css/flaticon.css">
  <link rel="stylesheet" href="assets/css/animate.min.css">
  <link rel="stylesheet" href="assets/css/magnific-popup.css">
  <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
  <link rel="stylesheet" href="assets/css/themify-icons.css">
  <link rel="stylesheet" href="assets/css/slick.css">
  <link rel="stylesheet" href="assets/css/nice-select.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    .lds-ellipsis {
      display: block;
      position: relative;
      width: 80px;
      height: 80px;
    }

    .lds-ellipsis div {
      position: absolute;
      top: 33px;
      width: 13px;
      height: 13px;
      border-radius: 50%;
      background: #000;
      animation-timing-function: cubic-bezier(0, 1, 1, 0);
    }

    .lds-ellipsis div:nth-child(1) {
      left: 8px;
      animation: lds-ellipsis1 0.6s infinite;
    }

    .lds-ellipsis div:nth-child(2) {
      left: 8px;
      animation: lds-ellipsis2 0.6s infinite;
    }

    .lds-ellipsis div:nth-child(3) {
      left: 32px;
      animation: lds-ellipsis2 0.6s infinite;
    }

    .lds-ellipsis div:nth-child(4) {
      left: 56px;
      animation: lds-ellipsis3 0.6s infinite;
    }

    @keyframes lds-ellipsis1 {
      0% {
        transform: scale(0);
      }

      100% {
        transform: scale(1);
      }
    }

    @keyframes lds-ellipsis3 {
      0% {
        transform: scale(1);
      }

      100% {
        transform: scale(0);
      }
    }

    @keyframes lds-ellipsis2 {
      0% {
        transform: translate(0, 0);
      }

      100% {
        transform: translate(24px, 0);
      }
    }
  </style>
</head>

<body style="overflow: hidden;">
  <?php include("head.php"); ?>
  <main>
    <div class="slider-area slider-height">
      <div class="slider-active">
        <div class="single-slider">
          <div class="slider-cap-wrapper">
            <div class="hero-caption">
              <h1 data-animation="fadeInUp" data-delay=".2s">
                Buxoro davlat universitetining
              </h1>
              <p data-animation="fadeInUp" data-delay=".6s">
                Online konferensiyalar saytiga xush kelibsiz
              </p>
            </div>
            <div class="hero-img position-relative">
              <img src="./assets/img/hero/hero-shape2.jpg" alt="" data-animation="fadeInRight" data-transition-duration="5s" />
            </div>
          </div>
        </div>
      </div>
    </div>

    <section class="popular-directorya-area section-padding fix">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-tittle text-center mb-40">
              <h2>Rejalashtirilgan konferensiyalar</h2>
              <p>
                Ushbu platforma orqali syil davomida 20 ta konferensiya tashkil etiladi
              </p>
            </div>
          </div>
        </div>
        <div class="directory-active">
          <div class="properties pb-20">
            <div class="properties-card">
              <div class="properties-img overlay1">
                <a><img src="./assets/img/gallery/top-it.jpg" alt="" /></a>
              </div>
              <div class="properties-caption">
                <h3>
                  <a>«АМАЛИЙ МАТЕМАТИКА ВА АХБОРОТ ТЕХНОЛОГИЯЛАРИНИНГ ЗАМОНАВИЙ МУАММОЛАРИ» МАВЗУСИДА ХАЛҚАРО ИЛМИЙ-АМАЛИЙ КОНФЕРЕНЦИЯСИНИНГ</a>
                </h3>
                <p>15.04.2021- 16.04.2021 kunlari</p>
              </div>
            </div>
          </div>
         <div class="properties pb-20">
            <div class="properties-card">
              <div class="properties-img overlay1">
                <a><img src="./assets/img/gallery/top-it.jpg" alt="" /></a>
              </div>
              <div class="properties-caption">
                <h3>
                  <a>«АМАЛИЙ МАТЕМАТИКА ВА АХБОРОТ ТЕХНОЛОГИЯЛАРИНИНГ ЗАМОНАВИЙ МУАММОЛАРИ» МАВЗУСИДА ХАЛҚАРО ИЛМИЙ-АМАЛИЙ КОНФЕРЕНЦИЯСИНИНГ</a>
                </h3>
                <p>15.04.2021- 16.04.2021 kunlari</p>
              </div>
            </div>
          </div>
         <div class="properties pb-20">
            <div class="properties-card">
              <div class="properties-img overlay1">
                <a><img src="./assets/img/gallery/top-it.jpg" alt="" /></a>
              </div>
              <div class="properties-caption">
                <h3>
                  <a>«АМАЛИЙ МАТЕМАТИКА ВА АХБОРОТ ТЕХНОЛОГИЯЛАРИНИНГ ЗАМОНАВИЙ МУАММОЛАРИ» МАВЗУСИДА ХАЛҚАРО ИЛМИЙ-АМАЛИЙ КОНФЕРЕНЦИЯСИНИНГ</a>
                </h3>
                <p>15.04.2021- 16.04.2021 kunlari</p>
              </div>
            </div>
          </div>
          <div class="properties pb-20">
            <div class="properties-card">
              <div class="properties-img overlay1">
                <a><img src="./assets/img/gallery/top-it.jpg" alt="" /></a>
              </div>
              <div class="properties-caption">
                <h3>
                  <a>«АМАЛИЙ МАТЕМАТИКА ВА АХБОРОТ ТЕХНОЛОГИЯЛАРИНИНГ ЗАМОНАВИЙ МУАММОЛАРИ» МАВЗУСИДА ХАЛҚАРО ИЛМИЙ-АМАЛИЙ КОНФЕРЕНЦИЯСИНИНГ</a>
                </h3>
                <p>15.04.2021- 16.04.2021 kunlari</p>
              </div>
            </div>
          </div>
         <div class="properties pb-20">
            <div class="properties-card">
              <div class="properties-img overlay1">
                <a><img src="./assets/img/gallery/top-it.jpg" alt="" /></a>
              </div>
              <div class="properties-caption">
                <h3>
                  <a>«АМАЛИЙ МАТЕМАТИКА ВА АХБОРОТ ТЕХНОЛОГИЯЛАРИНИНГ ЗАМОНАВИЙ МУАММОЛАРИ» МАВЗУСИДА ХАЛҚАРО ИЛМИЙ-АМАЛИЙ КОНФЕРЕНЦИЯСИНИНГ</a>
                </h3>
                <p>15.04.2021- 16.04.2021 kunlari</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="popular-directorya-area section-padding fix">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-tittle text-center mb-40">
              <h2>Maqolalar</h2>
            </div>
          </div>
        </div>
        
      </div>
    </section>

    
  </main>
  <?php include("footer.php") ?>

  <div id="back-top" style="display: none;">
    <a class="wrapper" title="Go to Top" href="#">
      <div class="arrows-container">
        <div class="arrow arrow-one"></div>
        <div class="arrow arrow-two"></div>
      </div>
    </a>
  </div>

  <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
  <script src="./assets/js/slick.min.js"></script>
  <script src="./assets/js/jquery.slicknav.min.js"></script>
  <script src="./assets/js/main.js"></script>
  <script>
    window.onload = function() {
      document.getElementById("loader").remove();
      document.getElementsByTagName("body")[0].style.overflow = "auto"
    }
  </script>
</body>


</html>