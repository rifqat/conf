<?php
require_once("connect.php");
$error = "";
$vals = array("fam", "ism", "otasi", "telefon", "email", "login", "parol", "parol2");
$pseudos = array("last name", "first name", "middle name", "phone number", "email", "login", "password", "confirm password");
$types = array("text", "text", "text", "text", "text", "text", "password", "password");
$reqs = array(4, 3, 4, 10, 10, 5, 6, 6);
if (isset($_POST['submit'])) {
    print_r($_POST);
    if ($_POST['parol'] !== $_POST['parol2']) {
        $error = "Passwords are not compatible";
    }
    foreach ($vals as $key => $value) {
        if (!isset($_POST) || strlen($_POST[$value]) < $reqs[$key]) {
            $error = "$pseudos[$key] error entered!!";
            break;
        }
    }
    if ($error == "") {
        $values = "";
        foreach ($vals as $key => $value) {
            
            if ($value != "parol2" && $value != "parol") {
                if ($values == "") {
                    $values = "'" . str_replace("'", "\'", $_POST[$value]) . "'";
                } else {
                    $values .= ", '" . str_replace("'", "\'", $_POST[$value]) . "'";
                }
            } else if ($value == "parol2"){
                $values .= ", '" . md5(str_replace("'", "\'", $_POST[$value])) . "'";
            }
        }
        $sql = "CALL reg_user($values);";
        if ($resp=mysqli_query($conn, $sql)){
            $row=mysqli_fetch_array($resp);
            if ($row['natija']==-1){
                $error="This phone number has been registered before. <br> Try logging in. <br> If you have lost your authentication information, <br> contact the admin!";
            } elseif ($row['natija']==-2){
                $error="This email was previously registered. <br> Try logging in. <br> If you have lost your authentication information, <br> contact the admin!";
            } elseif ($row['natija']==-3){
                $error="This login was previously registered. <br> Try logging in. <br> If you have lost your authentication information, <br> contact the admin!";
            } elseif ($row['natija']==1){
               header("location: ./in.php?msg=1");
            }
        } else {
            die(mysqli_error($conn));
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Register</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="login-bg" style="height: unset!important;">
    <main>

        <div class="register-form-area">
            <div class="register-form text-center">

                <div class="register-heading">
                    <span>Register</span>
			 <!-- <p> Registration in the system has been suspended due to the expiration of the deadline for submission of articles to the conference </p>  -->
			
            <p> Are you already registered? please  <a href="in.php" style="color: red!important"> Log in </a></p>
            <p class="text-danger" style="font-weight: 600;"><?= $error ?></p>
                </div>
                 <form autocomplete="off" action="" method="post">
                    <div class="input-box">

                        <?php foreach ($vals as $key => $value) { ?>
                            <div class="single-input-fields">
                                <label for="<?= $value ?>"><?= $pseudos[$key] ?>:</label>
                                <input <?php if ((isset($_POST['submit'])) && ($types[$key]!='password')){ echo "value='".$_POST[$value]."'"; } ?> autocomplete="off" type="<?= $types[$key] ?>" name="<?= $value ?>" id="<?= $value ?>">
                            </div>
                        <?php } ?>
                    </div>
                    <div class="register-footer">
                        
                        <input class="submit-btn3" type="submit" name="submit" value="Register">
                </form>
                
</body>

</html>