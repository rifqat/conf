﻿<?php
session_start();
require_once("../uz/connect.php");
check_user($conn);
if (isset($_POST['delete'])) {
    $id = intval($_POST['id']);
    $sql = "UPDATE maqola set state=-2 where id=$id;";
    if (!$resp = mysqli_query($conn, $sql)) {
        die(mysqli_error($conn));
    }
}
$error = "";
if (isset($_POST['submit'])) {
    if (isset($_POST['name']) && strlen($_POST['name']) > 3) {
        if (isset($_POST['shuba']) && $_POST['shuba'] > 0) {
            if (isset($_FILES['maqola']['name'])) {
                $allowed = array("pdf", "doc", "docx");
                $filename = $_FILES['maqola']['name'];
                $ext = pathinfo($filename, PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), $allowed)) {
                    $sql = "INSERT INTO maqola values(NULL, '" . str_replace("'", "\'", $_POST['name']) . "', CURRENT_DATE(), " . $_SESSION['id'] . ", 1, " . $_POST['shuba'] . ", '$ext')";
                    if ($resp = mysqli_query($conn, $sql)) {
                        $error = "Muvaffaqqiyatli yaratildi";
                        $sql = "SELECT id from maqola where user_id=" . $_SESSION['id'] . " ORDER BY id desc LIMIT 1";
                        $resp = mysqli_query($conn, $sql);
                        $row = mysqli_fetch_array($resp);
                        $target_file = "../uploads/" . $row['id'] . ".$ext";
                        move_uploaded_file($_FILES["maqola"]["tmp_name"], $target_file);
                    } else die(mysqli_error($conn));
               } else $error = "The file extension is incorrect!";
            } else $error = "The file extension is incorrect!";
        } else $error = "Section not selected!";
    } else $error = "Article title entered incorrectly!";
}
$sql = "SELECT m.name as name, m.id as id, m.state as state, m.ext as ext, s.name as sh_name, m.regdate as dates FROM maqola m INNER JOIN shuba s ON s.id=m.sh_id WHERE user_id=" . $_SESSION['id'] . " AND state>-2;";
if (!$resp = mysqli_query($conn, $sql)) {
    die(mysqli_error($conn));
}
$sql_i = "SELECT ism,fam,otasi from users WHERE id=" . $_SESSION['id'] . ";";
if (!$resp_i = mysqli_query($conn, $sql_i)) {
    die(mysqli_error($conn));
}
$row_i=mysqli_fetch_array($resp_i);
$name=$row_i['fam']." ".$row_i['ism']." ".$row_i['otasi'] ;
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My articles</title>
    <link rel="shortcut icon" type="image/x-icon" href="../uz/assets/img/icon/favicon.png" />
    <link href="../uz/css/style.min.css" rel="stylesheet">
    <style>
        .text-white th {
            color: white !important;
        }
    </style>
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php include("./head1.php"); ?>
        <?php include("menu.php"); ?>
        <div class="page-wrapper" style="min-height: 250px;">
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h4 class="text-center page-title">My articles <span class="text-danger"><?= $error ?></span></h4>
                    </div>

                </div>
            </div>
            <div class="container-fluid ">
                <div class="row  bg-white pt-3">
                    <div class="col-lg-12 col-xlg-12 col-md-12">
                        
                        <h3 class="text-center">My articles</h3>
                        <div style="overflow: auto">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr class="bg-info text-white">
                                        <th class="border-top-0">ID</th>
                                        <th class="border-top-0">Article title</th>
                                        <th class="border-top-0">Article session</th>
                                        <th class="border-top-0">User</th>
                                        <th class="border-top-0">Article regdate</th>
                                        <th class="border-top-0">Status</th>
                                        <th class="border-top-0">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 0;
                                    while ($row = mysqli_fetch_array($resp)) { ?>
                                        <tr>
                                            <td><?= ++$i ?></td>
                                            <td><?= str_replace(">", "&gt;", str_replace("<", "&lt;", $row['name'])) ?></td>
                                            <td><a href="../uploads/<?= $row['id'] ?>.<?= $row['ext'] ?>">Article</a></td>
                                            <td><?= $row['sh_name'] ?></td>
                                            <td><?= $row['dates'] ?></td>
                                            <td><?php switch ($row['state']) {
                                                    case '-1':
                                                        echo "Deleted because it does not meet the required level (does not meet the requirements of the section or thesis does not meet the required level)";
                                                        break;
                                                    case '0':
                                                        echo "Canceled because it does not meet the required level (does not meet the requirements of the section or thesis does not meet the required level)";
                                                        break;
                                                    case '1':
                                                        echo "Under consideration";
                                                        break;
                                                    case '2':
                                                        echo "Hello dear ".str_replace("/g",  "'", $name).". Your thesis was considered by the editorial board and recommended for publication.. 
Nashr xarajatlari uchun to`lovni <b class='text-danger'> 8600-1309-3005-9714 (Fazliddin Hazratov) </b> raqamli plastik kartochkaga amalga oshirib, skrinshotini mas`ul xodim Hazratov Fazliddin +998 (33) 407 8797 <a href='https://t.me/khazratof' target='_blank' > telegram </a> yoki <a href='mailto:hazratovf@gmail.com' > hazratovf@gmail.com  </a> Send a screenshot to hazratovf@gmail.com and information about who paid for it. (Payment is only for employees of educational institutions of the Republic of Uzbekistan. Free for foreign citizens) Sincerely, Conference Organizer. ";
							break;
						case '3':
                                                        echo "Hello dear ".str_replace("/g", "'", $name).". The requirements of the conference were fully met. We look forward to seeing you at our conference. You can access the conference  <a class='text-danger' href='#'>via this link</a> or <u  class='text-danger' >zoom app ### ### ### identifier and ##### with a password </u> Respectfully yours, Conference Organizer..";
							break;
						case '4':
                                                        echo "Hello dear ".str_replace("/g", "'", $name).". The requirements of the conference were fully met. We look forward to seeing you at our conference. You can access the conference  <a class='text-danger' href='https://us02web.zoom.us/#'>via this link</a> or <u  class='text-danger' >zoom app ######## identifier and ##### with a password </u> Respectfully yours, Conference Organizer.";
							break;
						case '5':
                                                        echo "Hello dear ".str_replace("/g", "'", $name).". The requirements of the conference were fully met. We look forward to seeing you at our conference. You can access the conference  <a  class='text-danger' href='https://us02web.zoom.us/j/###'>via this link</a> or <u  class='text-danger' > zoom app ######## identifier and #### with a password </u> Respectfully yours, Conference Organizer..";
							break;
                                                    default:
                                                        echo "Unknown error. Contact the admin";
                                                        break;
                                                }
                                                $row['dates'] ?></td>
                                            <td> <?php if ($row['state']<=1) {?>
                                                <form action="" method="post">
                                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                    <button name="delete" type="submit" class="btn btn-danger text-white"> <i class="fas fa-trash-alt"></i> </button>
                                                </form>
						<?php } else { ?>
							<button role="button" class="btn btn-success text-white"> <i class="fas fa-check"></i> </button>
						<?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if (0==0) { ?> <h3 class="text-center mt-4">Create new article</h3>
                        <div class="row">
                            <div class="card">
                                <div class="card-body">
                                    <!--  <p>Registration in the system has been suspended due to the expiration of the deadline for submission of articles to the conference</p>    -->

                                    <form method="POST" enctype="multipart/form-data" action="" class="form-horizontal form-material">
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Article name </label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <input name="name" type="text" class="form-control p-0 border-0">
                                            </div>
                                        </div>
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Article session</label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <select name="shuba" class="form-select shadow-none p-0 border-0 form-control-line">
                                                    <option value="0" , selected disabled>Not selected</option>
                                                    <?php
                                                    $sql1 = "SELECT `id`, `name` FROM shuba where active=1";
                                                   if ($resp1 = mysqli_query($conn, $sql1)) {
                                                        while ($row1 = mysqli_fetch_array($resp1)) { ?>
                                                            <option value="<?= $row1['id'] ?>"><?= $row1['name'] ?></option>
                                                    <?php }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Article</label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <input name="maqola" type="file" class="p-0 border-0">
                                            </div>
                                        </div>
                                        <div class="form-group mb-4">
                                            <div class="col-sm-12">
                                                <input type="submit" name="submit" class="btn btn-success" value="Save">
                                            </div>
                                        </div>
                                    </form> 
                                </div> <?php } ?>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            <footer class="footer text-center"> 2022 © Bukhara State University<a href="https://buxdu.uz/">Buxdu.uz</a>
            </footer>
        </div>
    </div>
    <script src="../uz/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="../uz/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../uz/js/app-style-switcher.js"></script>
    <script src="../uz/js/waves.js"></script>
    <script src="../uz/js/custom.js"></script>
</body>

</html>