<?php
require_once("connect.php");
session_start();
check_user($conn);
if ($_SESSION['active'] != 2) {
    header("location: ./maqolalar.php");
}
if (isset($_POST['state'])) {
    $state = intval($_POST['state']);
    $id = intval($_POST['id']);
    $sql = "UPDATE maqola set state=$state where id=$id;";
    if (!$resp = mysqli_query($conn, $sql)) {
        die(mysqli_error($conn));
    }
}
$get = "";
if (isset($_GET['s_id']) && $_GET['s_id'] > 0) $get = " AND s.id=" . intval($_GET['s_id']);
$sql = "SELECT m.id, m.state, m.name as  m_name, m.regdate, m.ext, u.fam, u.ism, u.otasi, u.tel, u.email, s.name as s_name from maqola m INNER JOIN users u ON u.id=m.user_id INNER JOIN shuba s ON m.sh_id=s.id where m.state>-1 $get ORDER BY m.id DESC";
if (isset($_GET['state']) && $_GET['state']!=-2){
    $sql = "SELECT m.id, m.state, m.name as  m_name, m.regdate, m.ext, u.fam, u.ism, u.otasi, u.tel, u.email, s.name as s_name from maqola m INNER JOIN users u ON u.id=m.user_id INNER JOIN shuba s ON m.sh_id=s.id where m.state=".intval($_GET['state'])." $get ORDER BY m.id DESC";
}
if (!$resp = mysqli_query($conn, $sql)) {
    die(mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Received articles</title>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png" />
    <link href="css/style.min.css" rel="stylesheet">
    <style>
        .text-white th {
            color: white !important;
        }

        td {
            overflow-wrap: break-word;
        }
    </style>
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php include("head1.php"); ?>
        <?php include("menu.php"); ?>
        <div class="page-wrapper" style="min-height: 250px;">
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Received articles</h4>
                    </div>

                </div>
            </div>
            <div class="container-fluid ">
                <div class="row  bg-white pt-3">
                    <div style="overflow: auto;" class="col-lg-12 col-xlg-12 col-md-12">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr class="bg-info text-white">
                                      <th class="border-top-0">Id</th>
                                    <th class="border-top-0">Article title</th>
                                    <th class="border-top-0">Article section</th>
                                    <th class="border-top-0">User</th>
                                    <th class="border-top-0">Article regdate</th>
                                    <th class="border-top-0">Status</th>
                                   <form action="" method="get">
                                        <select onchange="submit()" class="form-select" name="state" id="state">
                                            <option value="-2">All</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == -1) echo "selected"; ?> value="-1">Deleted</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 2) echo "selected"; ?> value="2">Accepted</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 3) echo "selected"; ?> value="3">Paid</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 5) echo "selected"; ?> value="5">Added to the collection</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 4) echo "selected"; ?> value="4">Foreign citizen</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 1) echo "selected"; ?> value="1">Under consideration</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 0) echo "selected"; ?> value="0">Canceled</option>
                                        </select>
                                    </form>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0;
                                while ($row = mysqli_fetch_array($resp)) { ?>
                                    <tr>
                                        <td><?= ++$i ?></td>
                                        <td style="width: 17%;"> <a download="<?= str_replace("/g", "'", str_replace(">", "&gt;", str_replace("<", "&lt;", $row['m_name']))) ?>" href="../uploads/<?= str_replace("/g", "'", $row['id']) ?>.<?= str_replace("/g", "'", $row['ext']) ?>"> <?= str_replace("/g", "'", str_replace(">", "&gt;", str_replace("<", "&lt;", $row['m_name']))) ?></a></td>
                                        <td><?= str_replace("/g", "'", $row['s_name']) ?></td>
                                        <td><?= str_replace("/g", "'", $row['fam']) ?> <?= str_replace("/g", "'", $row['ism']) ?> <?= str_replace("/g", "'", $row['otasi']) ?> <br><?= str_replace("/g", "'", $row['tel']) ?>, <?= str_replace("/g", "'", $row['email']) ?></td>
                                        <td> <?= str_replace("/g", "'", $row['regdate']) ?></td>
                                        <td>
                                            <form action="" method="POST">
                                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                <select onchange="submit()" class="form-select" name="state" id="state">
                                                    <option <?php if ($row['state'] == -1) echo "selected"; ?> value="-1">Deleted</option>
                                                    <option <?php if ($row['state'] == 2) echo "selected"; ?> value="2">Accepted</option>
                                                    <option <?php if ($row['state'] == 3) echo "selected"; ?> value="3">Paid</option>
                                                    <option <?php if ($row['state'] == 5) echo "selected"; ?> value="5">Added to the collection</option>
                                                    <option <?php if ($row['state'] == 4) echo "selected"; ?> value="4">Foreign citizen</option>
                                                    <option <?php if ($row['state'] == 1) echo "selected"; ?> value="1">Under consideration</option>
                                                    <option <?php if ($row['state'] == 0) echo "selected"; ?> value="0">Canceled</option>
                                                </select>
                                            </form>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <footer class="footer text-center"> 2022 © Bukhara State University <a href="https://buxdu.uz/">Buxdu.uz</a>
            </footer>
        </div>
    </div>
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>