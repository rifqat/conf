<?php
require_once("connect.php");
session_start();
check_user($conn);
if (isset($_POST['delete'])) {
    $id = intval($_POST['id']);
    $sql = "UPDATE shuba set active=0 where id=$id;";
    if (!$resp = mysqli_query($conn, $sql)) {
        die(mysqli_error($conn));
    }
}
$sql = "SELECT s.name as name, s.id as id, s.regdate as regdate, c.conf_name as cname FROM shuba s INNER JOIN conf c ON s.conf_id=c.id where active=1;";
if (!$resp = mysqli_query($conn, $sql)) {
    die(mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sho'balar</title>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png" />
    <link href="css/style.min.css" rel="stylesheet">
    <style>
        .text-white th {
            color: white !important;
        }
    </style>
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php include("head1.php"); ?>
        <?php include("menu.php"); ?>
        <div class="page-wrapper" style="min-height: 250px;">
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Sho'balar</h4>
                    </div>

                </div>
            </div>
            <div class="container-fluid ">
                <div class="row  bg-white pt-3">
                    <div class="col-lg-12 col-xlg-12 col-md-12">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr class="bg-info text-white">
                                    <th class="border-top-0">T/r</th>
                                    <th class="border-top-0">Sho'ba nomi</th>
                                    <th class="border-top-0">Konferensiya</th>
                                    <th class="border-top-0">Sho'ba yaratilgan sana</th>
                                    <?php if ($_SESSION['active'] == 2) {
                                        echo "<th> O'chirib tashlash </th>";
                                    } ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0;
                                while ($row = mysqli_fetch_array($resp)) { ?>
                                    <tr>
                                        <td><?= ++$i ?></td>
                                        <td><?= $row['name'] ?></td>
                                        <td><a href="maqola.php?s_id=<?= $row['id'] ?>" ><?= $row['cname'] ?></a></td>
                                        <td><?= $row['regdate'] ?></td>
                                        <?php if ($_SESSION['active'] == 2) { ?>
                                            <td>
                                                <form action="" method="post">
                                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                    <button name="delete" type="submit" class="btn btn-danger text-white"> <i class="fas fa-trash-alt"></i> </button>
                                                </form>
                                            </td>
                                        <?php  } ?>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if ($_SESSION['active'] == 2) { ?>
                        
                        <div class="row">
                            <div class="card">
                                <div class="card-body">
                                    <form method="POST" enctype="multipart/form-data" action="" class="form-horizontal form-material">
                                    <div class="col-lg-6 col-xlg-6 col-md-12 d-inline-block">
                                    <h3 class="text-center mt-4">Yangi sho'ba yaratish</h3>
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Sho'ba nomi </label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <input name="name" type="text" class="form-control p-0 border-0">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-xlg-6 col-md-12 d-inline-block">
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Sho'ba konferensiyasi</label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <select name="shuba" class="form-select shadow-none p-0 border-0 form-control-line">
                                                    <option value="0" , selected disabled>Tanlanmagan</option>
                                                    <?php
                                                    $sql1 = "SELECT `id`, `conf_name` FROM conf;";
                                                    if ($resp1 = mysqli_query($conn, $sql1)) {
                                                        while ($row1 = mysqli_fetch_array($resp1)) { ?>
                                                            <option value="<?= $row1['id'] ?>"><?= $row1['conf_name'] ?></option>
                                                    <?php }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group mb-4">
                                            <div class="col-sm-12">
                                                <input type="submit" name="submit" class="btn btn-success" value="Saqlash">
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php  } ?>
                </div>
            </div>
            <footer class="footer text-center"> 2021 © Buxoro davlat universiteti <a href="https://buxdu.uz/">Buxdu.uz</a>
            </footer>
        </div>
    </div>
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>