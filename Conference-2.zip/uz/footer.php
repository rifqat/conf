<footer>
    <div class="footer-area footer-padding">
      <div class="footer-wrapper">
        <div class="container">
          <div class="row d-flex justify-content-between">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
              <div class="single-footer-caption mb-50">
                <div class="single-footer-caption mb-30">
                  <div class="footer-logo mb-25">
                    <a href="#"><img style="width: 160px;" src="./assets/img/logo/logo.png" alt="" /></a>
                  </div>
                  <div class="footer-tittle">
                    <div class="footer-pera">
                      <p>
                        Buxoro davlat universiteti
                      </p>
                    </div>
                  </div>

                  <div class="footer-social">
                    <a href="https://www.youtube.com/channel/UCcMc65a0C355biazPbnT4hg"><i class="fab fa-youtube"></i></a>
                    <a href="https://www.facebook.com/buxdu/"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://t.me/buxdu_uz"><i class="fab fa-telegram"></i></a>
                    <a href="https://twitter.com/buxdu/"><i class="fab fa-twitter"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3">
              <div class="single-footer-caption mb-50">
                <div class="footer-tittle">
                  <h4>Foydali linklar</h4>
                  <ul>
                    <li><a href="#">Uniwork tizimi</a></li>
                    <li><a href="#">Moodle platformasi</a></li>
                    <li><a href="#">Hemis platformasi</a></li>

                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-4 col-sm-5">
              <div class="single-footer-caption mb-50">
                <div class="footer-tittle">
                  <h4>Sayt bo'yicha</h4>
                  <ul>
                  <li><a href="#">Qaydnoma tizimi</a></li>
                    <li><a href="#">Tizimga kirish</a></li>
                    <li><a href="#">Ro'yxatdan</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- <div class="col-xl-2 col-lg-2 col-md-4 col-sm-5">
              <div class="single-footer-caption mb-50">
                <div class="footer-tittle">
                  <h4>Company</h4>
                  <ul>
                    <li><a href="#">Design & creatives</a></li>
                    <li><a href="#">Telecommunication</a></li>
                    <li><a href="#">Restaurant</a></li>
                    <li><a href="#">Programing</a></li>
                    <li><a href="#">Architecture</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
              <div class="single-footer-caption mb-50">
                <div class="footer-tittle">
                  <h4>Newsletter</h4>
                  <p>Subscribe our newsletter to get updates.</p>
                </div>

                <div class="footer-form">
                  <div id="mc_embed_signup">
                    <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscribe_form relative mail_part" novalidate="true">
                      <input type="email" name="EMAIL" id="newsletter-form-email" placeholder="  Enter your email" />
                      <div class="form-icon">
                        <button type="submit" name="submit" id="newsletter-submit" class="email_icon newsletter-submit button-contactForm">
                          Subscribe
                        </button>
                      </div>
                      <div class="mt-10 info"></div>
                    </form>
                  </div>
                </div>
              </div>
            </div> -->
          </div>
        </div>

        <div class="footer-bottom-area">
          <div class="container">
            <div class="footer-border">
              <div class="row d-flex align-items-center">
                <div class="col-xl-12">
                  <div class="footer-copy-right text-center">
                    <p>
                      Copyright &copy;
                      <script>
                        document.write(new Date().getFullYear());
                      </script>
                      Barcha huquqlar himoyalangan | 
                      <a href="https://colorlib.com/" target="_blank" rel="nofollow noopener"> <i class="fa fa-heart color-danger" aria-hidden="true"></i> BuxDU.uz</a> tomonidan
                       yaratildi
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>