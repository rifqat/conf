<?php
session_start();
if (isset($_SESSION['lang']) && ($_SESSION['lang']!='uz')){
  if ($_SESSION['lang']=='ru' || $_SESSION['lang']=='en'){
    header("location: ../".$_SESSION['lang']."/");
  }
} else {
  $_SESSION['lang']='uz';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <meta name="author" content="Surjith S M">

  <!-- <script src="../../cdn-cgi/apps/head/OkbNSnEV_PNHTKP2_EYPrFNyZ8Q.js"></script> -->
  <link rel="shortcut icon" href="images/favicon.png">

  <title>Konferensiyalar - Buxoro davlat universiteti</title>

  <link href="css/bootstrap.min.css" rel="stylesheet">

  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,600' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

  <link href="css/plugins/animate.css" rel="stylesheet">
  <link href="css/plugins/slick.css" rel="stylesheet">
  <link href="css/plugins/magnific-popup.css" rel="stylesheet">
  <link href="css/plugins/font-awesome.css" rel="stylesheet">
  <link href="css/plugins/streamline-icons.css" rel="stylesheet">

  <link href="css/event.css" rel="stylesheet">


  <link href="css/themes/green.css" rel="stylesheet">


  <link rel="stylesheet" title="green" media="screen" href="css/themes/green.css">
  <link rel="alternate stylesheet" title="purple" media="screen" href="css/themes/purple.css">
  <link rel="alternate stylesheet" title="red" media="screen" href="css/themes/red.css">
  <link rel="alternate stylesheet" title="mint" media="screen" href="css/themes/mint.css">
  <link rel="alternate stylesheet" title="blue" media="screen" href="css/themes/blue.css">
  <link rel="alternate stylesheet" title="yellow" media="screen" href="css/themes/yellow.css">
  <link rel="alternate stylesheet" title="black" media="screen" href="css/themes/black.css">

  <link href="css/demo.css" rel="stylesheet">


  <!--[if lt IE 9]>
  <script src="js/ie/respond.min.js"></script>
  <![endif]-->

  <script src="js/modernizr.min.js"></script>

  <script>
    console.log(`<?=$_SERVER['PHP_SELF']?>`)
  </script>
  <script src="js/plugins/pace.js"></script>
<style>
.header_top-bg .btn-success:hover{
	background-color: white;
	color: #4eae49;
}

.header_top-bg .btn-success{
	background-color: transparent;
	color: white;
}

.footer_bottom-bg .btn-outline:hover{
	background-color: #4eae49;
	color: white;
}

.footer_bottom-bg .btn-outline{
	background-color:transparent;
	color: #4eae49;
}

.footer_bottom-bg .btn-success:hover{
	background-color:transparent;
	color: #4eae49;
}
.select_lang{
  padding: 0;
  margin: 0;
  position: fixed;
  right: 12px;
  top: 12px;
  color: #fff;
  z-index: 1050;
}

.select_lang li.active a{
  color: #fff;
  font-weight: 600;
}

.select_lang li{
  list-style-type: none;
}

.select_lang li{
  transition: all 0.4s ease;
  position: absolute;
  display: none;
  top: 0;
  right: 0;
  padding: 8px;
  z-index: -4;
}

.select_lang.show li{
  z-index: 1050;
  position: unset;
}

.select_lang li.active{
  display: block;
  z-index: 9;
  border-radius: 8px;
  background-color: #ccc;
}

.select_lang.show li{
  display: block;
}

.select_lang.show li a{
  background-color: #ccc;
  color: #fff;
 
}

ul.select_lang.show {
  transition: all 0.4s ease;
  background-color: #ccc;
  border-radius: 8px;
}

*{
  margin: 0;
}
</style>
</head>

<body class="animate-page" data-spy="scroll" data-target="#navbar" data-offset="100">

  <div class="preloader"></div>

  <nav class="navbar navbar-default navbar-fixed-top reveal-menu js-reveal-menu reveal-menu-hidden">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
          aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#"><img style="width: 100px;" src="images/logo.png" alt="Gather"> </a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="#talab">Talablar</a></li>
          <li><a href="#nearby">Konferensiyalar</a></li>
          <li><a href="#faq">Savollar</a></li>
          <li><a href="#sponsors" class="hidden-sm">Hamkorlar</a></li>
          <li><a href="#contact">Bog'lnish</a></li>
          <li><a href="up.php" class="btn btn-outline">Ro'yxatdan o'tish</a></li>
          </li>
        </ul>
      </div>

    </div>
  </nav>

  <header id="top" class="header">
    <ul class="select_lang">
      <li class="active"> <a href="#">UZ</a> </li>
      <li class=""> <a href="../?lang=en">EN</a></li>
    </ul>
    <div class="container">
      <div class="header_top-bg">
        <div class="logo">
          <a href="#"><img style="width: 150px;" src="images/logo.png" alt="event-logo"></a>
        </div>
      </div>
      <h3 class="headline-support wow fadeInDown">Salom,</h3>
      <h1 class="headline wow fadeInDown" data-wow-delay="0.1s">Buxoro Davlat Universitetining</h1>
      <div class="when_where wow fadeIn" data-wow-delay="0.4s">
        <p class="event_when">Onlayn konferensiyalar web sahifasiga xush kelibsiz</p>
      </div>
      <div class="header_top-bg">
	<a class="btn btn-outline btn-success btn-xl wow zoomIn" href="in.php">Tizimga kirish</a>
        <a class="btn btn-default btn-xl wow zoomIn" href="up.php">Ro'yxatdan o'tish</a>
        </p>
      </div>
    </div>

  </header>


  <section id="thegap" class="highlight">
    <div class="container">
      <p class="lead text-center">
        O‘zbekiston Respublikasi Vazirlar Mahkamasining 2021-yil 2-martdagi 78-F-son farmoyishini 1-ilovasi “2021-yilda o‘tkaziladigan xalqaro ilmiy va ilmiy-texnik tadbirlar rejasi”ga ko‘ra 2021-yil 15-aprel kuni Buxoro  davlat  universitetida “Amaliy matematika va axborot texnologiyalarining zamonaviy muammolari” mavzusida xalqaro ilmiy-amaliy konferensiya o‘tkaziladi.
      </p>
    </div>

  </section>



  <section id="talab" class="benefits">
    <div class="container">
      <div class="section-title wow fadeInUp">
        <h4>Nimalarni inobatga olish kerak?</h4>
      </div>
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <div class="row">
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInLeft">
                <div class="benefit-icon"><i class="icon icon-settings-streamline"> </i></div>
                <h6 class="benefit-title">Materiallarga qo'yilgan talab</h6>
                <p>Anjuman materiallari bir nusxada va elektron shakllarda ikkita fayl: maqola

                  (Olimovmaqola nomi) va talabnoma (Olimovzayavka) ko‘rinishida Word 2003- 2016 formatida Times New Roman, 14 kegl, satrlar oralig‘i 1,5, sahifalar chapdan va yuqoridan 2,5 sm, pastdan va o‘ngdan 2 sm qoldirilgan holda satr boshi - 1sm bo‘lishi shart.</p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInRight">
                <div class="benefit-icon"><i class="icon icon-settings-streamline-2"> </i></div>
                <h6 class="benefit-title">Ma'lumot o'rnida</h6>
                <p>Anjumanning tashkiliy badali va materiallar to‘plamining nashr xarajatlari har bir tezis uchun 50 000 so‘m deb belgilangan (xorijiy mualliflardan badal undirilmaydi). Taqdim etilayotgan tezis hajmi  4 betdan oshmasligi  talab etiladi. Anjuman materiallari o‘zbek, rus va ingliz tillarida qabul qilinadi. Bitta ishtirokchi ko‘pi bilan 2 ta maqola taqdim etishi mumkin.
                </p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInLeft">
                <div class="benefit-icon"><i class="icon icon-link-streamline"> </i></div>
                <h6 class="benefit-title">Manbalar</h6>
                <p>Manba va adabiyotga havola (ssilka) lar asosiy matn ichida [1] ko‘rinishda bo‘lishi lozim (naʼmunaga qarang).</p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInRight">
                <div class="benefit-icon"> <i class="icon icon-speech-streamline-talk-user"> </i></div>
                <h6 class="benefit-title">Muhim</h6>
                <p>Platformadan foydalanish, hisobni to'ldirish haqidagi savol, shikoyat va takliflaringizni tizim administratori Samadov Bobirga yuborishingiz mumkin</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>


  <section id="nearby" class="highlight accommodation">
    <div class="container">
      <div class="section-title wow fadeInUp">
        <h4>Yaqinlashib kelayotgan konferensiyalar</h4>
        <p>Konferensiyalar Xalq ta'limi vazirligining farmonlari bilan joriy etilgan bo'lib ma'lumotlar tasdiqlangan</p>
      </div>
      <div class="row">
        <div class="col-sm-offset-3 col-md-offset-4 col-sm-6 col-md-4">
          <div class="thumbnail wow fadeInUp">
            <img src="./assets/img/gallery/top-it.jpg" alt="Atholl Palace Hotel">
            <div class="caption">
              <h6>Amaliy matematika va axborot texnologiyalarining zamonaviy muammolari</h6>
              <p class="caption-text"></p>
              <p class="text-center"><i class="btn btn-outline" role="button">15-aprel kuni</i> </p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>


  <section id="faq" class="faq">
    <div class="container">
      <div class="section-title">
        <h5>Ko'pincha beriladigan savollar</h5>
      </div>
      <div class="row">
        <div class="col-md-6 wow fadeInLeft" data-wow-duration="2s">
          <h6 class="faq-title">Tizimdan qanday ro'yxatdan o'tishim mumkin?</h6>
          <p>Assalomu aleykum. Agar siz mobil telefon orqali kirayotgan bo'lsangiz unda yuqori o'ng burchakda menyu belgisi bor. Shu menyuda ro'yxatdan o'tish tugmasini bosishingiz yordamida Ro'yxatdan o'tish sahifasiga o'tishingiz mumkin.</p>
          <h6 class="faq-title">Tizimdan qanday ro'yxatdan o'tishim mumkin?</h6>
          <p>Assalomu aleykum. Agar siz mobil telefon orqali kirayotgan bo'lsangiz unda yuqori o'ng burchakda menyu belgisi bor. Shu menyuda ro'yxatdan o'tish tugmasini bosishingiz yordamida Ro'yxatdan o'tish sahifasiga o'tishingiz mumkin.</p>
        </div>
        <div class="col-md-6 wow fadeInRight" data-wow-duration="2s">
          <h6 class="faq-title">Tizimdan qanday ro'yxatdan o'tishim mumkin?</h6>
          <p>Assalomu aleykum. Agar siz mobil telefon orqali kirayotgan bo'lsangiz unda yuqori o'ng burchakda menyu belgisi bor. Shu menyuda ro'yxatdan o'tish tugmasini bosishingiz yordamida Ro'yxatdan o'tish sahifasiga o'tishingiz mumkin.</p>
          <h6 class="faq-title">Tizimdan qanday ro'yxatdan o'tishim mumkin?</h6>
          <p>Assalomu aleykum. Agar siz mobil telefon orqali kirayotgan bo'lsangiz unda yuqori o'ng burchakda menyu belgisi bor. Shu menyuda ro'yxatdan o'tish tugmasini bosishingiz yordamida Ro'yxatdan o'tish sahifasiga o'tishingiz mumkin.</p>
        </div>
      </div>
    </div>
  </section>


  <section class="sponsors" id="sponsors">
    <div class="container">
      <div class="section-title wow fadeInUp">
        <h4>Hamkorlarimiz:</h4>
      </div>
      <div class="sponsor-slider wow bounceIn">
        <div><img src="images/sponsor_1.png" class="img-responsive center-block" alt="sponsor"> </div>
        <div><img src="images/sponsor_2.png" class="img-responsive center-block" alt="sponsor"> </div>
        <div><img src="images/sponsor_3.png" class="img-responsive center-block" alt="sponsor"> </div>
        <div><img src="images/sponsor_4.png" class="img-responsive center-block" alt="sponsor"> </div>
        <div><img src="images/sponsor_1.png" class="img-responsive center-block" alt="sponsor"> </div>
        <div><img src="images/sponsor_2.png" class="img-responsive center-block" alt="sponsor"> </div>
        <div><img src="images/sponsor_3.png" class="img-responsive center-block" alt="sponsor"> </div>
        <div><img src="images/sponsor_4.png" class="img-responsive center-block" alt="sponsor"> </div>
      </div>
    </div>

  </section>


  <div class="highlight">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <div class="contact-box">
            <img src="images/location-icon.png" alt="location icon" class="wow zoomIn">
            <h5>Manzil</h5>
            <p>Buxoro shahar   
              <br>M.Iqbol ko`chasi
              <br>11-uy.
              <br>
              <br>Buxoro viloyat hokimligi binosi.
            </p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="contact-box">
            <img src="images/email-icon.png" alt="email icon" class="wow zoomIn" data-wow-delay="0.3s">
            <h5>Bog'lanish</h5>
            <p>
              <br> <a
                href="#"><span
                  class="__cf_email__"
                  >xxxxxxxx@xxxxx.xx</span></a>
              <br>
              <br> +998(xx)-xxx-xx-xx
              <br> +998(xx)-xxx-xx-xx
            </p>
          </div>
        </div>
      </div>

    </div>
  </div>

  <div class="container" id="contact">
    <div class="section-title">
      <h5>Yoki bizga xabar qoldiring</h5>
      <p>Xabarlaringiz o'rganilib chiqiladi va tez orada siz bilan bog'lanishadi</p>
    </div>
    <div class="contact-form bottom-space-xl wow fadeInUp">
      <form action="" id="phpcontactform" method="POST">
        <div class="row">
          <div class="col-md-6 col-md-offset-3">
            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label>Familiyangiz:</label>
                  <input type="text" class="form-control" name="first_name" placeholder="Familiyangiz..." required>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label>Ismingiz:</label>
                  <input type="text" class="form-control" name="last_name" placeholder="Ismingiz..." required>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label>Emlektron pochtangiz:</label>
              <input type="email" class="form-control" name="email" placeholder="example@com.ru" required>
            </div>
            <div class="form-group">
              <label>Telefon raqamingiz:</label>
              <input type="text" class="form-control" name="phone" placeholder="+998(XX)XXX-XX-XX" required>
            </div>
            <div class="form-group">
              <label>Xabaringiz:</label>
              <textarea class="form-control" name="message" rows="6" placeholder="Xabar..."
                required> </textarea>
            </div>
            <div class="text-center top-space">
              <button type="submit" class="btn btn-success btn-block btn-lg" id="js-contact-btn">Jo'natish</button>
              <div id="js-contact-result" data-success-msg="Form submitted successfully."
                data-error-msg="Oops. Something went wrong."></div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>


  <section class="footer-action">
    <div class="container">
      <h4 class="headline-support wow fadeInDown">Shoshiling,</h4>
      <h2 class="headline wow fadeInDown" data-wow-delay="0.1s">Muddat tugashiga oz vaqt qoldi</h2>
      <div class="footer_bottom-bg">
	<a class="btn btn-outline 1 btn-xl wow zoomIn" href="in.php">Tizimga kirish</a>
        <a class="btn btn-success btn-xl wow zoomIn" href="up.php" >Ro'yxatdan o'tish</a>
      </div>
    </div>
  </section>

  <footer>
    <div class="social-icons">
      <a href="#" class="wow zoomIn"> <i class="fa fa-twitter"></i> </a>
      <a href="#" class="wow zoomIn" data-wow-delay="0.2s"> <i class="fa fa-youtube"></i> </a>
      <a href="#" class="wow zoomIn" data-wow-delay="0.4s"> <i class="fa fa-facebook"></i> </a>
    </div>
    <p> <small class="text-muted">Buxdu.uz 2021 &copy; Barcha huquqlar himoyalangan</small></p>
  </footer>
  <a href="#top" class="back_to_top"><img src="images/back_to_top.png" alt="back to top"></a>
  <!-- <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
  <script src="js/jquery.min.js"></script>

  <script src="js/bootstrap.min.js"></script>

  <!-- <script src="js/plugins/countdown.js"></script> -->
  <script src="js/plugins/wow.js"></script>
  <script src="js/plugins/slick.js"></script>
  <script src="js/plugins/magnific-popup.js"></script>
  <!-- <script src="js/plugins/validate.js"></script> -->
  <script src="js/plugins/appear.js"></script>
  <!-- <script src="js/plugins/count-to.js"></script> -->
  <script src="js/plugins/nicescroll.js"></script>

  <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDMTUkJAmi1ahsx9uCGSgmcSmqDTBF9ygg"></script> -->
  <!-- <script src="js/plugins/infobox.js"></script> -->
  <!-- <script src="js/plugins/google-map.js"></script> -->
  <!-- <script src="js/plugins/directions.js"></script> -->

  <!-- <script src="js/plugins/style-switcher.js"></script> -->

  <!-- <script src="js/includes/subscribe.js"></script> -->
  <!-- <script src="js/includes/contact_form.js"></script> -->

  <script src="js/main.js"></script>
  <script>
    document.querySelector(".select_lang .active").addEventListener("click", function(){
      document.querySelector(".select_lang").classList.toggle("show");
    })
  </script>
</body>
</html>