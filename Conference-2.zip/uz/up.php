<?php
require_once("connect.php");
$error = "";
$vals = array("fam", "ism", "otasi", "telefon", "email", "login", "parol", "parol2");
$pseudos = array("familiyangiz", "ismingiz", "otangizning ismi", "telefon raqamingiz", "elektron pochtangiz", "login", "parol", "parolni tasdiqlang");
$types = array("text", "text", "text", "text", "text", "text", "password", "password");
$reqs = array(4, 3, 4, 10, 10, 5, 6, 6);
if (isset($_POST['submit'])) {
    print_r($_POST);
    if ($_POST['parol'] !== $_POST['parol2']) {
        $error = "Parollar mos kelmayapti";
    }
    foreach ($vals as $key => $value) {
        if (!isset($_POST) || strlen($_POST[$value]) < $reqs[$key]) {
            $error = "$pseudos[$key] xato kiritilgan!";
            break;
        }
    }
    if ($error == "") {
        $values = "";
        foreach ($vals as $key => $value) {
            
            if ($value != "parol2" && $value != "parol") {
                if ($values == "") {
                    $values = "'" . str_replace("'", "\'", $_POST[$value]) . "'";
                } else {
                    $values .= ", '" . str_replace("'", "\'", $_POST[$value]) . "'";
                }
            } else if ($value == "parol2"){
                $values .= ", '" . md5(str_replace("'", "\'", $_POST[$value])) . "'";
            }
        }
        $sql = "CALL reg_user($values);";
        if ($resp=mysqli_query($conn, $sql)){
            $row=mysqli_fetch_array($resp);
            if ($row['natija']==-1){
                $error="Ushbu telefon raqam ilgari ro'yxatdan o'tkazilgan. <br> Tizimga kirishga urinib ko'ring. <br> Autentifikatsiya ma'lumotlaringizni yo'qotgan <br> bo'lsangiz adminga murojaat qiling!";
            } elseif ($row['natija']==-2){
                $error="Ushbu elektron pochta ilgari ro'yxatdan o'tkazilgan. <br> Tizimga kirishga urinib ko'ring. <br> Autentifikatsiya ma'lumotlaringizni yo'qotgan <br> bo'lsangiz adminga murojaat qiling!";
            } elseif ($row['natija']==-3){
                $error="Ushbu login ro'yxatdan o'tkazilgan. <br> Tizimga kirishga urinib ko'ring. <br> Autentifikatsiya ma'lumotlaringizni yo'qotgan <br> bo'lsangiz adminga murojaat qiling!";
            } elseif ($row['natija']==1){
               header("location: ./in.php?msg=1");
            }
        } else {
            die(mysqli_error($conn));
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Ro'yxatdan o'tish</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="login-bg" style="height: unset!important;">
    <main>

        <div class="register-form-area">
            <div class="register-form text-center">

                <div class="register-heading">
                    <span>Ro'yxatdan o'tish</span>
			<!-- <p>Konferensiyaga maqola qabul qilish muddati tugaganligi sababli tizimdan ro'yxatdan o'tish vaqtincha to'xtatildi </p> -->



			<p> Allaqachon ro'yxatdan o'tganmisiz? Unda <a href="in.php" style="color: red!important"> Tizimga kiring </a></p>
            <p class="text-danger" style="font-weight: 600;"><?= $error ?></p>
                </div>

                 <form autocomplete="off" action="" method="post">
                    <div class="input-box">

                        <?php foreach ($vals as $key => $value) { ?>
                            <div class="single-input-fields">
                                <label for="<?= $value ?>"><?= $pseudos[$key] ?>:</label>
                                <input <?php if ((isset($_POST['submit'])) && ($types[$key]!='password')){ echo "value='".$_POST[$value]."'"; } ?> autocomplete="off" type="<?= $types[$key] ?>" name="<?= $value ?>" id="<?= $value ?>">
                            </div>
                        <?php } ?>
                    </div>
                    <div class="register-footer">
                        
                        <input class="submit-btn3" type="submit" name="submit" value="Register">
                </form>
               
</body>

</html>