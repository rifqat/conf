<style>
    .select_lang{
  padding: 0;
  margin: 0;
  position: absolute;
  right: 12px;
  top: 12px;
  color: #fff;
  z-index: 1050;
}

.select_lang li.active a{
  color: #fff;
  font-weight: 600;
}

.select_lang li{
  list-style-type: none;
}

.select_lang li{
  transition: all 0.4s ease;
  position: absolute;
  display: none;
  top: 0;
  right: 0;
  padding: 8px;
  z-index: -4;
}

.select_lang.show li{
  z-index: 1050;
  position: unset;
}

.select_lang li.active{
  display: block;
  z-index: 9;
  border-radius: 8px;
  background-color: #ccc;
}

.select_lang.show li{
  display: block;
}

.select_lang.show li a{
  background-color: #ccc;
  color: #fff;
 
}

ul.select_lang.show {
  transition: all 0.4s ease;
  background-color: #ccc;
  border-radius: 8px;
}
</style>
<header class="topbar">
    <nav class="navbar top-navbar navbar-expand-md navbar-light">
        <div class="navbar-header" style="box-shadow: 1px -8px 20px rgb(0 0 0 / 8%);" data-logobg="skin6">
            <!-- ============================================================== -->
            <!-- Logo -->
            <!-- ============================================================== -->
            <a class="navbar-brand" href="user.php">
                <!-- Logo icon -->
                <b class="logo-icon">
                    <!-- Dark Logo icon -->
                    <img style="width: 140px;" src="./assets/img/logo/logo.png" alt="" />
                </b>
                <!--End Logo icon -->
                <!-- Logo text -->
                <span class="logo-text">
                    <!-- dark Logo text -->
                    <!-- <img style="width: 190px;" src="./assets/img/logo/logo.png" alt="" /> -->
                </span>
            </a>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- toggle and nav items -->
            <!-- ============================================================== -->
            <a class="nav-toggler waves-effect waves-light text-dark d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
        </div>
        <!-- ============================================================== -->
        <!-- End Logo -->
        <!-- ============================================================== -->
    </nav>
    <div class="chang-lang">
        <ul class="select_lang">
            <li class="active"><a href="#">UZ</a></li>
            <li class=""> <a href="../?lang=en">EN</a> </li>
        </ul>
    </div>
</header>
<script>
    document.querySelector(".select_lang .active").addEventListener("click", function(){
      document.querySelector(".select_lang").classList.toggle("show");
    })
    document.querySelector(".select_lang li:not(.active) a").href=document.querySelector(".select_lang li:not(.active) a").href+"&return_url="+window.location.href.split("/")[window.location.href.split("/").length-1];
</script>