<?php
session_start();
$error = "";
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 1) {
        $_SESSION['msg'] = "Muvaffaqqiyatli ro'yxatdan o'tdingiz. marhamat tizimga kiring!";
    }
    header("location: ./in.php");
}
if (isset($_SESSION['msg']) && $_SESSION['msg'] != "") {
    $error = $_SESSION['msg'];
    $_SESSION['msg'] = "";
}
if (isset($_POST['submit'])) {
    require_once("connect.php");
    $sql = "SELECT id, parol,active FROM users where login='" . str_replace("'", "/g", $_POST['login']) . "' AND active>=1";
    if ($resp = mysqli_query($conn, $sql)) {
        $i=0;
        while ($row = mysqli_fetch_array($resp)) {
            $i++;
            if ($row['parol'] == md5(str_replace("'", "/g", $_POST['parol']))) {
                $_SESSION['id'] = $row['id'];
                $_SESSION['parol'] = $row['parol'];
                $_SESSION['active'] = $row['active'];
                header("location: ./maqolalar.php");
            } else {
                $error = "Login yoki parol xato!";
            }
        }
        if ($i==0){
            $error="Login yoki parol xato!";
        }
    } else {
        $error = "Login yoki parol xato!";
    }
}
?>

<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Tizimga kirish</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/icon/favicon.png" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
</head>

<body>
    <main class="login-bg">
        <div class="login-form-area">
            <div class="login-form">
                <form action="" method="post">
                    <div class="login-heading">
                        <span>Tizimga kirish  </span>
                        <p>
                            Akkauntingiz mavjud emasmi? Unda
                            <a class="text-danger" href="up.php">Ro'yxatdan o'ting</a>
                        </p>
                    </div>
                    <div class="w-100 bg-danger text-white text-center"><?= $error ?></div>
                    <div class="input-box">
                        <div class="single-input-fields">
                            <label>Loginingiz</label>
                            <input name="login" type="text" placeholder="Login..." />
                        </div>
                        <div class="single-input-fields">
                            <label>Parolingiz</label>
                            <input name="parol" type="password" placeholder="Parol..." />
                        </div>
                    </div>

                    <div class="login-footer d-flex justify-content-end">

                        <input type="submit" name="submit" value="Kirish" class="submit-btn3">
                    </div>
                </form>
            </div>
        </div>
    </main>
</body>

</html>