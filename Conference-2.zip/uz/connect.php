<?php

define('DB_NAME','buxduuz_conf');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_HOST','127.0.0.1');
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if (!$conn) {
die('Could not connect: ' . mysqli_connect_error());
}
function check_user($con){
    if (isset($_SESSION['id']) && $_SESSION['parol']){
        $sql="SELECT count(id) as x FROM users where id=".$_SESSION['id']." AND parol='".$_SESSION['parol']."';";
        if ($resp=mysqli_query($con, $sql)){
            while ($row=mysqli_fetch_array($resp)) {
                if ($row['x']<1){
                    header("location: ./");
                }
            }
        } else
        header("location: ./");
    }
    else
    header("location: ./");
}
?>