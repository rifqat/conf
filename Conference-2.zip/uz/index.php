﻿<?php
session_start();
if (isset($_SESSION['lang']) && ($_SESSION['lang']!='uz')){
  if ($_SESSION['lang']=='ru' || $_SESSION['lang']=='en'){
    header("location: ../".$_SESSION['lang']."/");
  }
} else {
  $_SESSION['lang']='uz';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <meta name="author" content="Surjith S M">

  <!-- <script src="../../cdn-cgi/apps/head/OkbNSnEV_PNHTKP2_EYPrFNyZ8Q.js"></script> -->
  <link rel="shortcut icon" href="images/favicon.png">

  <title>Konferensiyalar - Buxoro davlat universiteti</title>

  <link href="css/bootstrap.min.css" rel="stylesheet">

  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,600' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

  <link href="css/plugins/animate.css" rel="stylesheet">
  <link href="css/plugins/slick.css" rel="stylesheet">
  <link href="css/plugins/magnific-popup.css" rel="stylesheet">
  <link href="css/plugins/font-awesome.css" rel="stylesheet">
  <link href="css/plugins/streamline-icons.css" rel="stylesheet">

  <link href="css/event.css" rel="stylesheet">


  <link href="css/themes/green.css" rel="stylesheet">


  <link rel="stylesheet" title="green" media="screen" href="css/themes/green.css">
  <link rel="alternate stylesheet" title="purple" media="screen" href="css/themes/purple.css">
  <link rel="alternate stylesheet" title="red" media="screen" href="css/themes/red.css">
  <link rel="alternate stylesheet" title="mint" media="screen" href="css/themes/mint.css">
  <link rel="alternate stylesheet" title="blue" media="screen" href="css/themes/blue.css">
  <link rel="alternate stylesheet" title="yellow" media="screen" href="css/themes/yellow.css">
  <link rel="alternate stylesheet" title="black" media="screen" href="css/themes/black.css">

  <link href="css/demo.css" rel="stylesheet">


  <!--[if lt IE 9]>
  <script src="js/ie/respond.min.js"></script>
  <![endif]-->

  <script src="js/modernizr.min.js"></script>

  <script>
    console.log(`<?=$_SERVER['PHP_SELF']?>`)
  </script>
  <script src="js/plugins/pace.js"></script>
<style>
.header_top-bg .btn-success:hover{
	background-color: white;
	color: #4eae49;
}

.header_top-bg .btn-success{
	background-color: transparent;
	color: white;
}

.footer_bottom-bg .btn-outline:hover{
	background-color: #4eae49;
	color: white;
}

.footer_bottom-bg .btn-outline{
	background-color:transparent;
	color: #4eae49;
}

.footer_bottom-bg .btn-success:hover{
	background-color:transparent;
	color: #4eae49;
}
.select_lang{
  padding: 0;
  margin: 0;
  position: fixed;
  right: 12px;
  top: 12px;
  color: #fff;
  z-index: 1050;
}

.select_lang li.active a{
  color: #fff;
  font-weight: 600;
}

.select_lang li{
  list-style-type: none;
}

.select_lang li{
  transition: all 0.4s ease;
  position: absolute;
  display: none;
  top: 0;
  right: 0;
  padding: 8px;
  z-index: -4;
}

.select_lang.show li{
  z-index: 1050;
  position: unset;
}

.select_lang li.active{
  display: block;
  z-index: 9;
  border-radius: 8px;
  background-color: #ccc;
}

.select_lang.show li{
  display: block;
}

.select_lang.show li a{
  background-color: #ccc;
  color: #fff;
 
}

ul.select_lang.show {
  transition: all 0.4s ease;
  background-color: #ccc;
  border-radius: 8px;
}

*{
  margin: 0;
}
</style>
</head>

<body class="animate-page" data-spy="scroll" data-target="#navbar" data-offset="100">

  <div class="preloader"></div>

  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
          aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="http://conf.buxdu.uz"><img style="width: 100px;" src="images/logo.png" alt="Gather"> </a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="index.php#bosh">Bosh sahifa</a></li>
          <li><a href="../uploads/2022/Dastur_(Xalqaro konferensiya -2022 - BuxDU).pdf">Dastur</a></li>
          <li><a href="../uploads/2022/TUPLAM_(Xalqaro konferensiya-2022-BuxDU).pdf">To`plam</a></li>
         
                <li class="dropdown">
                    <a href="#flyer" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Axborot xati<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="../uploads/flyer/Xalqaro konferensiya-2022-3_en.pdf">Axborot xati(EN)</a></li>
                        <li><a href="../uploads/flyer/Xalqaro konferensiya-2022-1_uz.pdf">Axborot xati(UZ)</a></li>
                        <li><a href="../uploads/flyer/Xalqaro konferensiya-2022-2_ru.pdf">Axborot xati(RU)</a></li>                        
                    </ul>
                </li>
            <li class="dropdown">
                    <a href="#files" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Fayllar<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="../files/cert/index.php">Sertifikatlar</a></li>
                        <li><a href=".#">Media</a></li>               
                    </ul>
            </li>
            <li><a href="#contact">Bog'lanish</a></li>
            <li><a href="in.php">Kirish</a></li>
          <li><a href="up.php" class="btn btn-outline">Ro'yxatdan o'tish</a></li>
          </li>
        </ul>
      </div>

    </div>
  </nav>

  <header id="top" class="header">
    <ul class="select_lang">
      <li class="active"> <a href="#">UZ</a> </li>
      <li class=""> <a href="../?lang=en">EN</a></li>
    </ul>
    <div class="container">
      <div class="header_top-bg">
        <div class="logo">
              
          
          <img style="width: 150px;" src="../uz/images/sponsor_1.png" data-toggle="tooltip" title="O`zbekiston Milliy Universiteti">
       
          <img style="width: 150px;" src="../uz/images/sponsor_2.png" data-toggle="tooltip" title="O`zR FA V.I.Romanovskiy nomidagi Matematika instituti">

          <img style="width: 150px;" src="../uz/images/sponsor_3.png" data-toggle="tooltip" title="Toshkent davlat transport universiteti ">

          <img style="width: 250px;" src="../uz/images/buxdu.png" data-toggle="tooltip" title="Buxoro davlat universiteti" >

        </div>
        <b>O‘zbekiston Milliy universiteti, O‘zR FA V.I.Romanovskiy nomidagi Matematika instituti, Toshkent davlat transport universiteti va Buxoro davlat universiteti hamkorligida</b>
      </div>
      
      <h1 class="headline wow fadeInDown" data-wow-delay="0.1s">“Amaliy matematika va axborot texnologiyalarining zamonaviy muammolari” mavzusida xalqaro ilmiy-amaliy konferensiya</h1> 
       <h3><small>(2022 yil 11-12 may kunlari)<small></h3>
        <h4 class="headline wow fadeInDown" data-wow-delay="0.1s">Maqolalar 2022 yilning 30 apreligacha qabul qilinadi</h4>
      <div class="header_top-bg">
      <div class="header_top-bg2">
	<a class="btn btn-outline btn-success btn-xl wow zoomIn" href="in.php">Tizimga kirish</a>
        <a class="btn btn-default btn-xl wow zoomIn" href="up.php">Ro'yxatdan o'tish</a>
        </p>
      </div>
    </div>

  </header>

<div class="highlight">
    <div class="container">
      <div class="row">
          
          <div class="well well-lg text-danger"><h3>Konferensiyaga maqola qabul qilish muddati tugadi</h3>
          </div>
      
      </div>
    </div>
  </div>

  



<section id="nearby" class="highlight accommodation">
    <div class="container">
      <div class="section-title wow fadeInUp">
        <h4>SHO`BALAR</h4>       
      </div>
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>1-seksiya. Matematik analiz.</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>2-seksiya. Algebra va geometriya</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>3-seksiya. Differensial tenglamalar va matematik fizika</h6>             
            </div>
          </div>
        </div>
        
         <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>4-seksiya. Hisoblash matematikasi va matematik modellashtirish</h6>             
            </div>
          </div>
        </div>


      </div>

      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>5-seksiya. Algoritmlar nazariyasi va dasturlash texnologiyalari</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>6-seksiya. Sun’iy intellekt</h6>             
            </div>
          </div>
        </div>

          <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>7-seksiya. Axborot xavfsizligi</h6>             
            </div>
          </div>
        </div>
        
         <div class="col-sm-6 col-md-3">
          <div class="thumbnail wow fadeInUp">           
            <div class="caption">
              <h6>8-seksiya. Ta’limda raqamli texnologiyalar</h6>             
            </div>
          </div>
        </div>


      </div>
    </div>

  </section>



  <section id="talab" class="benefits">
    <div class="container">
      <div class="section-title wow fadeInUp">
        <h4>Nimalarni inobatga olish kerak?</h4>
      </div>
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <div class="row">
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInLeft">
                <div class="benefit-icon"><i class="icon icon-settings-streamline"> </i></div>
                <h6 class="benefit-title">Materiallarga qo'yilgan talab</h6>
                <p>Anjuman materiallari bir nusxada va elektron shaklda quyidagi "FIO_maqola_nomi.docx(doc)" ko‘rinishida Word formatida Times New Roman, 14 kegl, satrlar oralig‘i 1,5, sahifalar chapdan va yuqoridan 2,5 sm, pastdan va o‘ngdan 2 sm qoldirilgan holda satr boshi - 1sm bo‘lishi shart.Taqdim etilayotgan maqola hajmi  2 betdan oshmasligi  talab etiladi</p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInRight">
                <div class="benefit-icon"><i class="icon icon-settings-streamline-2"> </i></div>
                <h6 class="benefit-title">Ma'lumot o'rnida</h6>
                <p>Anjumanning tashkiliy badali va materiallar to‘plamining nashr xarajatlari har bir tezis uchun 100 000 so‘m deb belgilangan (xorijiy mualliflardan badal undirilmaydi). Taqdim etilayotgan maqola hajmi  2 betdan oshmasligi  talab etiladi. Anjuman materiallari o‘zbek, rus va ingliz tillarida qabul qilinadi. Bitta ishtirokchi ko‘pi bilan 2 ta maqola taqdim etishi mumkin.
                </p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInLeft">
                <div class="benefit-icon"><i class="icon icon-link-streamline"> </i></div>
                <h6 class="benefit-title">Manbalar</h6>
                <p>Manba va adabiyotga havola (ssilka) lar asosiy matn ichida [1] ko‘rinishda bo‘lishi lozim (naʼmunaga qarang).</p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="benefit-item wow fadeInRight">
                <div class="benefit-icon"> <i class="icon icon-speech-streamline-talk-user"> </i></div>
                <h6 class="benefit-title">Muhim</h6>
                <p>Xalqaro konferensiyada ishtirok etish uchun maqolalar 2022 yilning 30 apreligacha qabul qilinadi.Tanlangan maqolalar anjuman tugaganidan keyin SCOPUS, Web of science ilmiy-tekshirish jurnallarida chop etilishi rejalashtirilgan. Platformadan foydalanish, hisobni to'ldirish haqidagi savol, shikoyat va takliflaringizni tizim administratori Hazratov Fazliddinga yuborishingiz mumkin</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>




 


  <div class="highlight">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <div class="contact-box">
            <img src="images/location-icon.png" alt="location icon" class="wow zoomIn">
            <h5>Manzil</h5>
            <p>Buxoro shahar   
              <br>M.Iqbol ko`chasi
              <br>11-uy.
              <br>
              <br>Mo`ljal: Buxoro viloyat hokimligi binosi.
            </p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="contact-box">
            <img src="images/email-icon.png" alt="email icon" class="wow zoomIn" data-wow-delay="0.3s">
            <h5>Bog'lanish</h5>
              <p>
              <br> <a
                href="https://t.me/confbuxduuz"><span
                  class="__cf_telegramm__">https://t.me/confbuxduuz</span></a>
              <br>
              <br> +998 (33) 407 8797 - Fazliddin Hazratov              
              <br> +998 (91) 648 3529 - Ozod Jalolov
              <br> Е-mail: hazratovf@gmail.com 
              <br> Plastik karta raqami: 8600-1309-3005-9714 (Fazliddin Hazratov)
            </p>
          </div>
        </div>
      </div>

    </div>
  </div>

  

  <footer>    
    <p> <small class="text-muted">Buxdu.uz 2022 &copy; Barcha huquqlar himoyalangan</small></p>
  </footer>
  <a href="#top" class="back_to_top"><img src="images/back_to_top.png" alt="back to top"></a>
  <!-- <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
  <script src="js/jquery.min.js"></script>

  <script src="js/bootstrap.min.js"></script>

  <!-- <script src="js/plugins/countdown.js"></script> -->
  <script src="js/plugins/wow.js"></script>
  <script src="js/plugins/slick.js"></script>
  <script src="js/plugins/magnific-popup.js"></script>
  <!-- <script src="js/plugins/validate.js"></script> -->
  <script src="js/plugins/appear.js"></script>
  <!-- <script src="js/plugins/count-to.js"></script> -->
  <script src="js/plugins/nicescroll.js"></script>

  <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDMTUkJAmi1ahsx9uCGSgmcSmqDTBF9ygg"></script> -->
  <!-- <script src="js/plugins/infobox.js"></script> -->
  <!-- <script src="js/plugins/google-map.js"></script> -->
  <!-- <script src="js/plugins/directions.js"></script> -->

  <!-- <script src="js/plugins/style-switcher.js"></script> -->

  <!-- <script src="js/includes/subscribe.js"></script> -->
  <!-- <script src="js/includes/contact_form.js"></script> -->

  <script src="js/main.js"></script>
  <script>
    document.querySelector(".select_lang .active").addEventListener("click", function(){
      document.querySelector(".select_lang").classList.toggle("show");
    })
  </script>
</body>
</html>