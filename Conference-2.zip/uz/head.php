<div id="loader" style="position: absolute; height: 100vh; background: #fff; z-index: 99999; width: 100%; ">
    <div style="top: 47%; left:47%;" class="lds-ellipsis">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
  <header>
    <div class="header-area">
      <div class="main-header header-sticky">
        <div class="container-fluid">
          <div class="menu-wrapper d-flex align-items-center justify-content-between">
            <div class="left-content d-flex align-items-center">
              <div class="logo">
                <a href="index.php"><img style="width: 190px;" src="./assets/img/logo/logo.png" alt="" /></a>
              </div>
            </div>

            <div class="main-menu d-none d-lg-block">
              <nav>
                <ul id="navigation">
                  <li><a href="./">Bosh sahifa</a></li>
                  <li>
                    <a href="news.php">Yangiliklar</a>
                  </li>
                  <li><a href="contact.php">Bog'lanish</a></li>
                  <li>
                    <a href="in.php" class="btn header-btn2">Tizimga kirish</a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
          <div class="mobile_menu d-block d-lg-none"></div>
        </div>
      </div>
    </div>
  </header>
