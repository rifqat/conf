<?php
require_once("connect.php");
session_start();
check_user($conn);
if ($_SESSION['active'] != 2) {
    header("location: ./maqolalar.php");
}
if (isset($_POST['state'])) {
    $state = intval($_POST['state']);
    $id = intval($_POST['id']);
    $sql = "UPDATE maqola set state=$state where id=$id;";
    if (!$resp = mysqli_query($conn, $sql)) {
        die(mysqli_error($conn));
    }
}
$get = "";

$s_filtr=" ";
if(isset($_GET['shuba']) && $_GET['shuba'] > 0){
  $s_filtr = ' AND s.id='.$_GET['shuba'];
}
//echo $_GET['shuba'].$s_filtr;


if (isset($_GET['s_id']) && $_GET['s_id'] > 0) $get = " AND s.id=" . intval($_GET['s_id']);
$sql = "SELECT m.id, m.state, m.name as  m_name, m.regdate, m.ext, u.fam, u.ism, u.otasi, u.tel, u.email, s.name as s_name from maqola m INNER JOIN users u ON u.id=m.user_id INNER JOIN shuba s ON m.sh_id=s.id where m.state>-1 $get  $s_filtr  ORDER BY m.id DESC";
if (isset($_GET['state']) && $_GET['state']!=-2){
    $sql = "SELECT m.id, m.state, m.name as  m_name, m.regdate, m.ext, u.fam, u.ism, u.otasi, u.tel, u.email, s.name as s_name from maqola m INNER JOIN users u ON u.id=m.user_id INNER JOIN shuba s ON m.sh_id=s.id where m.state=".intval($_GET['state'])." $get  $s_filtr  ORDER BY m.id DESC";
}
if (!$resp = mysqli_query($conn, $sql)) {
    die(mysqli_error($conn));
}

$shubasql="select id,name from shuba";
if (!$res_shuba = mysqli_query($conn, $shubasql)) {
    die(mysqli_error($conn));
}


?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelib tushgan maqolalar</title>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png" />
    <link href="css/style.min.css" rel="stylesheet">
    <style>
        .text-white th {
            color: white !important;
        }

        td {
            overflow-wrap: break-word;
        }
        body{
             overflow-x: scroll;
             overflow-y: scroll;
        }
    </style>
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php include("head1.php"); ?>
        <?php include("menu.php"); ?>
        <div class="page-wrapper" style="min-height: 250px;">
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Kelib tushgan maqolalar</h4>
                    </div>

                </div>
            </div>
            <div class="container-fluid ">
                <div class="row  bg-white pt-3">
                    <div style="overflow: auto;" class="col-lg-12 col-xlg-12 col-md-12">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr class="bg-info text-white">
                                    <th class="border-top-0">T/r</th>
                                    <th class="border-top-0">Maqola nomi</th>
                                    <th class="border-top-0">Maqola sho'basi
                                         <form action="" method="get">
                                        <select class="form-select" name="shuba" id="shuba">
                                            <option value="-1">Barchasi</option>
                                            <?php
                                             while($s_row= mysqli_fetch_assoc($res_shuba)):
                                               echo '<option value='.$s_row['id'];
                                               if (isset($_GET['shuba']) && $_GET['shuba'] == $s_row['id']) echo " selected ";
                                               echo '>'.$s_row['name'].'</option>'; 
                                              endwhile; ?> 
                                        </select>                                    

                                    </th>
                                    <th class="border-top-0">Foydalanuvchi</th>
                                    <th class="border-top-0">Maqola regdate</th>
                                    <th class="border-top-0">Holati
                                   
                                        <select onchange="submit()" class="form-select" name="state" id="state">
                                            <option value="-2">Barchasi</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == -1) echo "selected"; ?> value="-1">O'chirib yuborildi</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 2) echo "selected"; ?> value="2">Qabul qilindi</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 3) echo "selected"; ?> value="3">To'lov qilindi</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 5) echo "selected"; ?> value="5">To'plamga qo'shildi</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 4) echo "selected"; ?> value="4">Chet el fuqarosi</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 1) echo "selected"; ?> value="1">Ko'rib chiqilmoqda</option>
                                            <option <?php if (isset($_GET['state']) && $_GET['state'] == 0) echo "selected"; ?> value="0">Bekor qilindi</option>
                                        </select>
                                    </form>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0;
                                while ($row = mysqli_fetch_array($resp)) { ?>
                                    <tr>
                                        <td><?= ++$i ?></td>
                                        <td style="width: 17%;"> <a download="<?= str_replace("/g", "'", str_replace(">", "&gt;", str_replace("<", "&lt;", $row['m_name']))) ?>" href="../uploads/<?= str_replace("/g", "'", $row['id']) ?>.<?= str_replace("/g", "'", $row['ext']) ?>"> <?= str_replace("/g", "'", str_replace(">", "&gt;", str_replace("<", "&lt;", $row['m_name']))) ?></a></td>
                                        <td><?= str_replace("/g", "'", $row['s_name']) ?></td>
                                        <td><?= str_replace("/g", "'", $row['fam']) ?> <?= str_replace("/g", "'", $row['ism']) ?> <?= str_replace("/g", "'", $row['otasi']) ?> <br><?= str_replace("/g", "'", $row['tel']) ?>, <?= str_replace("/g", "'", $row['email']) ?></td>
                                        <td> <?= str_replace("/g", "'", $row['regdate']) ?></td>
                                        <td>
                                            <form action="" method="POST">
                                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                <select onchange="submit()" class="form-select" name="state" id="state">
                                                    <option <?php if ($row['state'] == -1) echo "selected"; ?> value="-1">O'chirib yuborildi</option>
                                                    <option <?php if ($row['state'] == 2) echo "selected"; ?> value="2">Qabul qilindi</option>
                                                    <option <?php if ($row['state'] == 3) echo "selected"; ?> value="3">To'lov qilindi</option>
                                                    <option <?php if ($row['state'] == 5) echo "selected"; ?> value="5">To'plamga qo'shildi</option>
                                                    <option <?php if ($row['state'] == 4) echo "selected"; ?> value="4">Chet el fuqarosi</option>
                                                    <option <?php if ($row['state'] == 1) echo "selected"; ?> value="1">Ko'rib chiqilmoqda</option>
                                                    <option <?php if ($row['state'] == 0) echo "selected"; ?> value="0">Bekor qilindi</option>
                                                </select>
                                            </form>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <footer class="footer text-center"> 2021 © Buxoro davlat universiteti <a href="https://buxdu.uz/">Buxdu.uz</a>
            </footer>
        </div>
    </div>
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>