﻿<?php
session_start();
require_once("connect.php");
check_user($conn);
if (isset($_POST['delete'])) {
    $id = intval($_POST['id']);
    $sql = "UPDATE maqola set state=-2 where id=$id;";
    if (!$resp = mysqli_query($conn, $sql)) {
        die(mysqli_error($conn));
    }
}
$error = "";
if (isset($_POST['submit'])) {
    if (isset($_POST['name']) && strlen($_POST['name']) > 3) {
        if (isset($_POST['shuba']) && $_POST['shuba'] > 0) {
            if (isset($_FILES['maqola']['name'])) {
                $allowed = array("pdf", "doc", "docx");
                $filename = $_FILES['maqola']['name'];
                $ext = pathinfo($filename, PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), $allowed)) {
                    $sql = "INSERT INTO maqola values(NULL, '" . str_replace("'", "\'", $_POST['name']) . "', CURRENT_DATE(), " . $_SESSION['id'] . ", 1, " . $_POST['shuba'] . ", '$ext')";
                    if ($resp = mysqli_query($conn, $sql)) {
                        $error = "Muvaffaqqiyatli yaratildi";
                        $sql = "SELECT id from maqola where user_id=" . $_SESSION['id'] . " ORDER BY id desc LIMIT 1";
                        $resp = mysqli_query($conn, $sql);
                        $row = mysqli_fetch_array($resp);
                        $target_file = "../uploads/" . $row['id'] . ".$ext";
                        move_uploaded_file($_FILES["maqola"]["tmp_name"], $target_file);
                    } else die(mysqli_error($conn));
                } else $error = "Fayl kengaytmasi noto'g'ri!";
            } else $error = "Fayl kengaytmasi noto'g'ri!";
        } else $error = "Sho'ba tanlanmadi";
    } else $error = "Maqola nomi xato kiritilgan!";
}
$sql = "SELECT m.name as name, m.id as id, m.state as state, m.ext as ext, s.name as sh_name, m.regdate as dates FROM maqola m INNER JOIN shuba s ON s.id=m.sh_id WHERE user_id=" . $_SESSION['id'] . " AND state>-2;";
if (!$resp = mysqli_query($conn, $sql)) {
    die(mysqli_error($conn));
}
$sql_i = "SELECT ism,fam,otasi from users WHERE id=" . $_SESSION['id'] . ";";
if (!$resp_i = mysqli_query($conn, $sql_i)) {
    die(mysqli_error($conn));
}
$row_i=mysqli_fetch_array($resp_i);
$name=$row_i['fam']." ".$row_i['ism']." ".$row_i['otasi'] ;
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Maqolalarim</title>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/img/icon/favicon.png" />
    <link href="css/style.min.css" rel="stylesheet">
    <style>
        .text-white th {
            color: white !important;
        }
    </style>
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php include("head1.php"); ?>
        <?php include("menu.php"); ?>
        <div class="page-wrapper" style="min-height: 250px;">
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h4 class="text-center page-title">Maqolalarim <span class="text-danger"><?= $error ?></span></h4>
                    </div>

                </div>
            </div>
            <div class="container-fluid ">
                <div class="row  bg-white pt-3">
                    <div class="col-lg-12 col-xlg-12 col-md-12">
                        
                        <h3 class="text-center">Mening maqolalarim</h3>
                        <div style="overflow: auto">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr class="bg-info text-white">
                                        <th class="border-top-0">T/r</th>
                                        <th class="border-top-0">Maqola nomi</th>
                                        <th class="border-top-0">Maqola fayli</th>
                                        <th class="border-top-0">Sho'ba nomi</th>
                                        <th class="border-top-0">Topshirilgan vaqti</th>
                                        <th class="border-top-0">Holati</th>
                                        <th class="border-top-0">O'chirib tashlash</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 0;
                                    while ($row = mysqli_fetch_array($resp)) { ?>
                                        <tr>
                                            <td><?= ++$i ?></td>
                                            <td><?= str_replace(">", "&gt;", str_replace("<", "&lt;", $row['name'])) ?></td>
                                            <td><a href="../uploads/<?= $row['id'] ?>.<?= $row['ext'] ?>">Maqola</a></td>
                                            <td><?= $row['sh_name'] ?></td>
                                            <td><?= $row['dates'] ?></td>
                                            <td><?php switch ($row['state']) {
                                                    case '-1':
                                                        echo "Qo'yilgan talab darajasida bo'lmagani uchun o'chirildi (Bo'limga mos emas yoki tezisning talab darajasiga mos emas)";
                                                        break;
                                                    case '0':
                                                        echo "Qo'yilgan talab darajasida bo'lmagani uchun bekor qilindi (Bo'limga mos emas yoki tezisning talab darajasiga mos emas)";
                                                        break;
                                                    case '1':
                                                        echo "Ko'rib chiqilmoqda";
                                                        break;
                                                    case '2':
                                                        echo "Salom hurmatli ".str_replace("/g",  "'", $name).". Sizning yuborgan tezisingiz redkollegiya tomonidan ko`rib chiqildi va nashrga tavfsiya berildi. 
Nashr xarajatlari uchun to`lovni <b class='text-danger'> 8600-1309-3005-9714 (Fazliddin Hazratov)  </b> raqamli plastik kartochkaga amalga oshirib, skrinshotini mas`ul xodim Fazliddin Hazratovga (+998 (33) 407 8797 <a href='https://t.me/khazratof' target='_blank' > telegram </a> yoki <a href='mailto:hazratovf@gmail.com' > hazratovf@gmail.com  </a> elektron pochtasiga skrinshotini va kim tomondan to`langanligi haqida ma`lumotni yetkazing.  (To'lov faqat O'zbekiston Respublikasi ta'lim muassasalarida ishlovchi xodimlar uchun. Chet ellik fuqarolar uchun bepul)
Hurmat bilan Konferensiya tashkilotchisi. ";
							break;
						case '3':
                                                        echo "Salom hurmatli ".str_replace("/g", "'", $name).". Konferensiya talablari to'la bajarildi. Sizni konferensiyamizda kutib qolamiz. Konferensiyaga <a class='text-danger' href='#'>ushbu havola</a> yoki <u  class='text-danger' >Zoom ilovasi orqali ### ### #### identifikator va #### parol orqali </u> kirishingiz mumkin. Hurmat bilan Konferensiya tashkilotchisi.";
							break;
						case '4':
                                                        echo "Salom hurmatli ".str_replace("/g", "'", $name).". Konferensiya talablari to'la bajarildi. Sizni konferensiyamizda kutib qolamiz. Konferensiyaga <a class='text-danger' href='#'>ushbu havola</a> yoki <u  class='text-danger' >Zoom ilovasi orqali ### ### #### identifikator va ##### parol orqali </u> kirishingiz mumkin. Hurmat bilan Konferensiya tashkilotchisi.";
							break;
						case '5':
                                                        echo "Salom hurmatli ".str_replace("/g", "'", $name).". Konferensiya talablari to'la bajarildi. Sizni konferensiyamizda kutib qolamiz. Konferensiyaga <a  class='text-danger' href='#'>ushbu havola</a> yoki <u  class='text-danger' > Zoom ilovasi orqali ### ### #### identifikator va #### parol orqali </u> kirishingiz mumkin. Hurmat bilan Konferensiya tashkilotchisi.";
							break;
                                                    default:
                                                        echo "Noma'lum xatolik. Adminga murojaat qiling";
                                                        break;
                                                }
                                                $row['dates'] ?></td>
                                            <td> <?php if ($row['state']<=1) {?>
                                                <form action="" method="post">
                                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                    <button name="delete" type="submit" class="btn btn-danger text-white"> <i class="fas fa-trash-alt"></i> </button>
                                                </form>
						<?php } else { ?>
							<button role="button" class="btn btn-success text-white"> <i class="fas fa-check"></i> </button>
						<?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if (0==0) { ?> <h3 class="text-center mt-4">Yangi maqola yaratish</h3>
                        <div class="row">
                            <div class="card">
                                <div class="card-body">
                                        <p>Konferensiyaga maqola qabul qilish muddati tugaganligi sababli tizimdan ro'yxatdan o'tish vaqtincha to'xtatildi</p>
                                   <!--  <form method="POST" enctype="multipart/form-data" action="" class="form-horizontal form-material">
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Maqola nomi </label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <input name="name" type="text" class="form-control p-0 border-0">
                                            </div>
                                        </div>
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Maqola sho'basi</label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <select name="shuba" class="form-select shadow-none p-0 border-0 form-control-line">
                                                    <option value="0" , selected disabled>Tanlanmagan</option>
                                                    <?php
                                                    $sql1 = "SELECT `id`, `name` FROM shuba where active=1";
                                                   if ($resp1 = mysqli_query($conn, $sql1)) {
                                                        while ($row1 = mysqli_fetch_array($resp1)) { ?>
                                                            <option value="<?= $row1['id'] ?>"><?= $row1['name'] ?></option>
                                                    <?php }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group mb-4">
                                            <label class="col-md-12 p-0">Maqola</label>
                                            <div class="col-md-12 border-bottom p-0">
                                                <input name="maqola" type="file" class="p-0 border-0">
                                            </div>
                                        </div>
                                        <div class="form-group mb-4">
                                            <div class="col-sm-12">
                                                <input type="submit" name="submit" class="btn btn-success" value="Saqlash">
                                            </div>
                                        </div>
                                    </form> -->
                                </div> <?php } ?>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            <footer class="footer text-center"> 2022 © Buxoro davlat universiteti <a href="https://buxdu.uz/">Buxdu.uz</a>
            </footer>
        </div>
    </div>
    <script src="./plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="./bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/app-style-switcher.js"></script>
    <script src="./js/waves.js"></script>
    <script src="./js/custom.js"></script>
</body>

</html>