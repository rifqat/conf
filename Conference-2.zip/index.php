<?php
session_start();
if (isset($_GET['lang'])){
    $_SESSION['lang']=$_GET['lang'];
}
require 'uz/connect.php';
$lang='en';
// if (isset($_SESSION['lang']) && ($_SESSION['lang']!='uz')){
//   if ($_SESSION['lang']!='ru' || $_SESSION['lang']!='en'){
//     $_SESSION['lang']='uz';
//   }
// }
if (isset($_SESSION['id'])){
    $sql="SELECT lang FROM users WHERE id=".intval($_SESSION['id']);
    $resp=mysqli_query($conn, $sql);
    if (!$resp){
        mysqli_error($conn);
    }
    $r_lang=mysqli_fetch_array($resp);
    if ($r_lang['lang']!==NULL){
        $lang=$r_lang['lang'];
    } else {
        $sql="UPDATE users SET lang='".$_SESSION['lang']."' WHERE id=".intval($_SESSION['id']);
        if (!$resp=mysqli_query($conn, $sql)){
            die(mysqli_error($conn));
        }
    }
    if ($lang!=$_SESSION['lang'] && isset($_GET['lang'])){
        $sql="UPDATE users SET lang='".$_SESSION['lang']."' WHERE id=".intval($_SESSION['id']);
        if (!$resp=mysqli_query($conn, $sql)){
            die(mysqli_error($conn));
        }
        var_dump($resp);
    }
} else {
    if (!isset($_SESSION['lang'])){
        $_SESSION['lang']='en';
    }
}
echo "$lang ".$_SESSION['lang'];
header("location: ./".$_SESSION['lang']."/".$_GET['return_url']);
?>
